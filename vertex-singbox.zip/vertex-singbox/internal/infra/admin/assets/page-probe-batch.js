// page-probe-batch.js — 【节点故障策略与记录】页的批量手动探测入口。
//
// 与批量测速共用同一份进度（/nodes/test-progress）与暂停/终止接口，
// 因此这里只在 prog.kind === 'probe' 时接管进度展示，避免把节点页的
// 「批量测速」进度误标成本页的探测进度。

let probeProgressTimer = null;
let probePaused = false;

// probeDisabledNodes 读取「仅探测健康禁用节点」复选框并发起批量探测。
async function probeDisabledNodes() {
  const cb = document.getElementById('faultProbeHealthOnly');
  const healthOnly = cb ? !!cb.checked : true;
  try {
    const res = await API.nodes.probeDisabled(healthOnly);
    const total = (res && res.total) || 0;
    if (!total) {
      toast('没有可探测的禁用节点');
      return;
    }
    toast('开始批量探测 ' + total + ' 个' + (healthOnly ? '健康禁用' : '禁用') + '节点...');
    showProbeProgressUI({ done: 0, total: total, ok_count: 0, fail_count: 0, current_node: '准备中...' });
    startProbeProgressPolling();
  } catch (e) {
    toast('启动批量探测失败: ' + e.message, 'err');
  }
}

function startProbeProgressPolling() {
  if (probeProgressTimer) return;
  probeProgressTimer = setInterval(async function () {
    try {
      const prog = await API.nodes.testProgress();
      // kind 不是 probe（例如节点页正在批量测速）时不接管本页进度。
      if (prog && prog.running && prog.kind === 'probe') {
        showProbeProgressUI(prog);
        return;
      }
      clearInterval(probeProgressTimer);
      probeProgressTimer = null;
      const el = document.getElementById('probeProgress');
      if (el) el.style.display = 'none';
      toast('批量探测结束');
      if (typeof refreshFaultsPage === 'function') refreshFaultsPage();
    } catch (e) { /* 轮询失败下一轮重试 */ }
  }, 1000);
}

function showProbeProgressUI(prog) {
  const el = document.getElementById('probeProgress');
  const text = document.getElementById('probeProgressText');
  const fill = document.getElementById('probeProgressFill');
  const detail = document.getElementById('probeProgressDetail');
  const btnPause = document.getElementById('btnProbePauseResume');
  if (!el) return;
  el.style.display = 'block';
  probePaused = !!prog.paused;
  if (btnPause) {
    btnPause.textContent = probePaused ? '恢复' : '暂停';
    btnPause.className = 'btn ghost';
  }
  const done = prog.done || 0;
  const total = prog.total || 1;
  const ok = prog.ok_count || 0;
  const failed = prog.fail_count || 0;
  if (fill) fill.style.width = Math.round(done / total * 100) + '%';
  if (text) text.textContent = (probePaused ? '已暂停' : '探测中') + ' ' + done + '/' + total + ' · 通过 ' + ok + ' · 失败 ' + failed;
  if (detail) detail.textContent = '当前状态: ' + (prog.current_node || '');
}

async function toggleProbePauseResume() {
  try {
    if (probePaused) {
      await API.nodes.testResume();
      probePaused = false;
      const btnPause = document.getElementById('btnProbePauseResume');
      if (btnPause) { btnPause.textContent = '暂停'; btnPause.className = 'btn ghost'; }
      startProbeProgressPolling();
      toast('已恢复批量探测');
    } else {
      await API.nodes.testPause();
      probePaused = true;
      const btnPause = document.getElementById('btnProbePauseResume');
      if (btnPause) { btnPause.textContent = '恢复'; btnPause.className = 'btn ghost'; }
      const text = document.getElementById('probeProgressText');
      if (text && text.textContent.startsWith('探测中')) {
        text.textContent = text.textContent.replace(/^探测中/, '已暂停');
      }
      toast('已暂停批量探测');
    }
  } catch (e) {
    toast('操作失败: ' + e.message, 'err');
  }
}

async function terminateProbeBatch() {
  try {
    await API.nodes.testTerminate();
    if (probeProgressTimer) { clearInterval(probeProgressTimer); probeProgressTimer = null; }
    const el = document.getElementById('probeProgress');
    if (el) el.style.display = 'none';
    toast('已终止批量探测');
  } catch (e) {
    toast('终止失败: ' + e.message, 'err');
  }
}
