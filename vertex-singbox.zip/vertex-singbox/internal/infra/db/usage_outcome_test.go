package db

import (
	"database/sql"
	"testing"
	"time"
)

// TestDeriveOutcome 锁定结果分类推导口径（Issue #14 答复 2）。
func TestDeriveOutcome(t *testing.T) {
	cases := []struct {
		name       string
		success    bool
		statusCode int
		want       string
	}{
		{"成功", true, 200, OutcomeSuccess},
		{"客户端取消", false, StatusClientCanceled, OutcomeCanceled},
		{"管理员停止", false, StatusAdminCanceled, OutcomeCanceled},
		{"上游 4xx", false, 404, OutcomeUpstream4xx},
		{"上游 429", false, 429, OutcomeUpstream4xx},
		{"上游 5xx", false, 500, OutcomeUpstream5xx},
		{"上游 503", false, 503, OutcomeUpstream5xx},
		{"网络错误 502", false, 502, OutcomeUpstreamNetworkErr},
		{"未设状态码", false, 0, OutcomeUpstream5xx},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			if got := DeriveOutcome(c.success, c.statusCode); got != c.want {
				t.Fatalf("DeriveOutcome(%v,%d)=%q, want %q", c.success, c.statusCode, got, c.want)
			}
		})
	}
}

// TestIsNonUpstreamOutcome 适配层拒绝与取消都不属于上游故障。
func TestIsNonUpstreamOutcome(t *testing.T) {
	for outcome, want := range map[string]bool{
		OutcomeAdapterRejected:    true,
		OutcomeCanceled:           true,
		OutcomeSuccess:            false,
		OutcomeUpstream4xx:        false,
		OutcomeUpstream5xx:        false,
		OutcomeUpstreamNetworkErr: false,
	} {
		if got := IsNonUpstreamOutcome(outcome); got != want {
			t.Errorf("IsNonUpstreamOutcome(%q)=%v, want %v", outcome, got, want)
		}
	}
}

// TestAggregateExcludesAdapterRejected 适配层拒绝不计入成功/失败，单独计入 AdapterRejected；
// 上游 4xx/5xx/网络错误照常计入失败（统计闭环，Issue #14 第三节）。
func TestAggregateExcludesAdapterRejected(t *testing.T) {
	s := memStore(t)
	base := time.Now().Unix()

	recs := []UsageRecord{
		{TS: base, Model: "m", Success: true, StatusCode: 200, Outcome: OutcomeSuccess},
		{TS: base, Model: "m", Success: false, StatusCode: 400, Outcome: OutcomeAdapterRejected},
		{TS: base, Model: "m", Success: false, StatusCode: 400, Outcome: OutcomeAdapterRejected},
		{TS: base, Model: "m", Success: false, StatusCode: 404, Outcome: OutcomeUpstream4xx},
		{TS: base, Model: "m", Success: false, StatusCode: 500, Outcome: OutcomeUpstream5xx},
		{TS: base, Model: "m", Success: false, StatusCode: 502, Outcome: OutcomeUpstreamNetworkErr},
	}
	for i, r := range recs {
		if err := s.Insert(r); err != nil {
			t.Fatalf("Insert %d: %v", i, err)
		}
	}

	sum, err := s.Aggregate(base-60, base+60)
	if err != nil {
		t.Fatalf("Aggregate: %v", err)
	}
	if sum.Requests != 6 {
		t.Errorf("Requests=%d, want 6（拒绝仍计入请求总数）", sum.Requests)
	}
	if sum.Success != 1 {
		t.Errorf("Success=%d, want 1", sum.Success)
	}
	if sum.Errors != 3 {
		t.Errorf("Errors=%d, want 3（仅上游 4xx/5xx/网络；适配层拒绝不计入）", sum.Errors)
	}
	if sum.AdapterRejected != 2 {
		t.Errorf("AdapterRejected=%d, want 2", sum.AdapterRejected)
	}

	// 分组与趋势同口径。
	rows, err := s.ByModel(base-60, base+60)
	if err != nil {
		t.Fatalf("ByModel: %v", err)
	}
	if len(rows) != 1 || rows[0].Errors != 3 || rows[0].AdapterRejected != 2 {
		t.Fatalf("ByModel 口径不一致: %+v", rows)
	}
	pts, err := s.DailySeries(base-60, base+60, 86400)
	if err != nil {
		t.Fatalf("DailySeries: %v", err)
	}
	if len(pts) != 1 || pts[0].Errors != 3 || pts[0].AdapterRejected != 2 {
		t.Fatalf("DailySeries 口径不一致: %+v", pts)
	}
}

// TestHistoryCarriesOutcome 历史行回传 outcome，供面板区分适配层拒绝。
func TestHistoryCarriesOutcome(t *testing.T) {
	s := memStore(t)
	base := time.Now().Unix()
	if err := s.Insert(UsageRecord{
		TS: base, Model: "m", Success: false, StatusCode: 400,
		Outcome: OutcomeAdapterRejected, ErrorReason: "unsupported image URL",
	}); err != nil {
		t.Fatalf("Insert: %v", err)
	}
	page, err := s.History(1, 10)
	if err != nil {
		t.Fatalf("History: %v", err)
	}
	if len(page.Items) != 1 {
		t.Fatalf("items=%d, want 1", len(page.Items))
	}
	if page.Items[0].Outcome != OutcomeAdapterRejected {
		t.Errorf("outcome=%q, want %q", page.Items[0].Outcome, OutcomeAdapterRejected)
	}
}

// TestMigrateUsageLog_OutcomeCompat 旧库兼容性：模拟"没有 outcome 列"的历史库，
// 迁移后列被补回（默认 ”），且**历史记录口径完全不变**——旧行不会被误判为
// adapter_rejected，取消仍按 status_code 计入 canceled。
func TestMigrateUsageLog_OutcomeCompat(t *testing.T) {
	database, err := sql.Open("sqlite", ":memory:")
	if err != nil {
		t.Fatalf("open: %v", err)
	}
	defer func() { _ = database.Close() }()
	if err := createTables(database); err != nil {
		t.Fatalf("createTables: %v", err)
	}
	// 模拟旧库：删掉本版本新增的 outcome 列。
	if _, err := database.Exec("ALTER TABLE usage_log DROP COLUMN outcome"); err != nil {
		t.Skipf("当前 sqlite 不支持 DROP COLUMN，跳过旧库模拟: %v", err)
	}

	// 迁移应把列补回来（幂等 ALTER TABLE ADD COLUMN，默认 ''）。
	if err := migrateUsageLog(database); err != nil {
		t.Fatalf("migrateUsageLog: %v", err)
	}

	s := NewUsageStore(database)
	base := time.Now().Unix()
	// 旧记录：Outcome 留空（等价于迁移后的默认 ''）。
	recs := []UsageRecord{
		{TS: base, Model: "m", Success: true, StatusCode: 200},
		{TS: base, Model: "m", Success: false, StatusCode: 500},
		{TS: base, Model: "m", Success: false, StatusCode: StatusClientCanceled},
		{TS: base, Model: "m", Success: false, StatusCode: StatusAdminCanceled},
	}
	for i, r := range recs {
		if err := s.Insert(r); err != nil {
			t.Fatalf("Insert %d（迁移后新 INSERT 必须可用）: %v", i, err)
		}
	}

	sum, err := s.Aggregate(base-60, base+60)
	if err != nil {
		t.Fatalf("Aggregate: %v", err)
	}
	// 历史口径与加 outcome 列之前完全一致：成功/失败按 success，取消按 status_code。
	if sum.Requests != 4 || sum.Success != 1 || sum.Errors != 1 || sum.Canceled != 2 {
		t.Fatalf("旧库口径漂移: %+v", sum)
	}
	if sum.AdapterRejected != 0 {
		t.Fatalf("旧记录不得被误判为 adapter_rejected: %+v", sum)
	}
}
