package db

import (
	"testing"
	"time"
)

// TestAggregateExcludesCanceled 取消类（498 客户端中断 / 499 管理员停止）不计入成功/失败，
// 但仍计入请求总数，并单独落在 canceled 桶里；上游取消（502）照常计入失败。
func TestAggregateExcludesCanceled(t *testing.T) {
	s := memStore(t)
	base := time.Now().Unix()

	recs := []UsageRecord{
		{TS: base, Model: "m", Success: true, StatusCode: 200, TotalTokens: 10},
		{TS: base, Model: "m", Success: false, StatusCode: 502, TotalTokens: 5}, // 上游取消 → 失败
		{TS: base, Model: "m", Success: false, StatusCode: StatusClientCanceled},
		{TS: base, Model: "m", Success: false, StatusCode: StatusAdminCanceled},
	}
	for i, r := range recs {
		if err := s.Insert(r); err != nil {
			t.Fatalf("Insert %d: %v", i, err)
		}
	}

	sum, err := s.Aggregate(base-60, base+60)
	if err != nil {
		t.Fatalf("Aggregate: %v", err)
	}
	if sum.Requests != 4 {
		t.Errorf("Requests=%d, want 4（取消仍计入总数）", sum.Requests)
	}
	if sum.Success != 1 {
		t.Errorf("Success=%d, want 1", sum.Success)
	}
	if sum.Errors != 1 {
		t.Errorf("Errors=%d, want 1（仅 502；498/499 不计入）", sum.Errors)
	}
	if sum.Canceled != 2 {
		t.Errorf("Canceled=%d, want 2", sum.Canceled)
	}

	// 分组与趋势同口径。
	rows, err := s.ByModel(base-60, base+60)
	if err != nil {
		t.Fatalf("ByModel: %v", err)
	}
	if len(rows) != 1 || rows[0].Success != 1 || rows[0].Errors != 1 || rows[0].Canceled != 2 {
		t.Fatalf("ByModel 口径不一致: %+v", rows)
	}
	pts, err := s.DailySeries(base-60, base+60, 86400)
	if err != nil {
		t.Fatalf("DailySeries: %v", err)
	}
	if len(pts) != 1 || pts[0].Success != 1 || pts[0].Errors != 1 || pts[0].Canceled != 2 {
		t.Fatalf("DailySeries 口径不一致: %+v", pts)
	}
}

// TestIsCanceledStatus 锁定取消类状态码判定。
func TestIsCanceledStatus(t *testing.T) {
	for code, want := range map[int]bool{
		StatusClientCanceled: true,
		StatusAdminCanceled:  true,
		200:                  false,
		500:                  false,
		502:                  false,
		503:                  false,
	} {
		if got := IsCanceledStatus(code); got != want {
			t.Errorf("IsCanceledStatus(%d)=%v, want %v", code, got, want)
		}
	}
}
