package logger

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// DailyLogger implements an io.Writer that writes to logs_latest.log.
// On Close, it appends the content to a daily log file and clears logs_latest.log.
type DailyLogger struct {
	mu        sync.Mutex
	logDir    string
	latestFd  *os.File
	done      chan struct{}
	closeOnce sync.Once
}

// NewDailyLogger creates a new DailyLogger that writes logs to the specified directory.
func NewDailyLogger(dir string) *DailyLogger {
	_ = os.MkdirAll(dir, 0755)

	latestPath := filepath.Join(dir, "logs_latest.log")
	f, _ := os.OpenFile(latestPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)

	if f != nil {
		now := time.Now()
		startupMsg := fmt.Sprintf("\n========== STARTUP: %s (Timestamp: %d) ==========\n", now.Format("2006-01-02 15:04:05"), now.Unix())
		_, _ = f.WriteString(startupMsg)
	}

	dl := &DailyLogger{
		logDir:   dir,
		latestFd: f,
		done:     make(chan struct{}),
	}
	go dl.cleanupRoutine()
	return dl
}

func (l *DailyLogger) Write(p []byte) (n int, err error) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.latestFd == nil {
		return 0, fmt.Errorf("logger closed")
	}
	return l.latestFd.Write(p)
}

// Clear 清空当前 logs_latest.log 的内容，并写入一行标记便于确认操作生效。
//
// 实现说明：日志句柄以 O_APPEND 常开，Windows 下该句柄只带 FILE_APPEND_DATA，
// 直接对其调用 Truncate 会 ACCESS_DENIED；因此另开一个 O_WRONLY|O_TRUNC 句柄完成
// 「截断 + 写标记」（Go 在 Windows 默认以 FILE_SHARE_READ|WRITE 打开，两个句柄可共存），
// 原追加句柄依旧有效，后续写入从新的 EOF 继续。整个过程持锁，避免与并发 Write 交错。
func (l *DailyLogger) Clear() error {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.latestFd == nil {
		return fmt.Errorf("logger closed")
	}
	f, err := os.OpenFile(filepath.Join(l.logDir, "logs_latest.log"), os.O_WRONLY|os.O_TRUNC, 0666)
	if err != nil {
		return err
	}
	_, werr := f.WriteString(fmt.Sprintf("\n========== LOG CLEARED: %s ==========\n", time.Now().Format("2006-01-02 15:04:05")))
	cerr := f.Close()
	if werr != nil {
		return werr
	}
	return cerr
}

func (l *DailyLogger) Close() error {
	l.closeOnce.Do(func() {
		close(l.done)
	})

	l.mu.Lock()
	defer l.mu.Unlock()

	if l.latestFd != nil {
		_ = l.latestFd.Close()
		l.latestFd = nil
	}

	latestPath := filepath.Join(l.logDir, "logs_latest.log")
	nowDate := time.Now().Format("2006-01-02")
	targetPath := filepath.Join(l.logDir, fmt.Sprintf("vproxy-%s.log", nowDate))

	latestData, _ := os.ReadFile(latestPath)

	// Create or open the target file regardless of whether there's data
	f, err := os.OpenFile(targetPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
	if err == nil {
		if len(latestData) > 0 {
			_, _ = f.Write(latestData)
		}
		_ = f.Close()
	}

	// Always remove logs_latest.log
	_ = os.Remove(latestPath)

	return nil
}

func (l *DailyLogger) cleanupRoutine() {
	ticker := time.NewTicker(1 * time.Hour)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			l.cleanup()
		case <-l.done:
			return
		}
	}
}

func (l *DailyLogger) cleanup() {
	l.mu.Lock()
	defer l.mu.Unlock()
	entries, err := os.ReadDir(l.logDir)
	if err != nil {
		return
	}
	cutoff := time.Now().Add(-7 * 24 * time.Hour)
	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".log") {
			continue
		}
		info, err := entry.Info()
		if err == nil && info.ModTime().Before(cutoff) {
			_ = os.Remove(filepath.Join(l.logDir, entry.Name()))
		}
	}
}
