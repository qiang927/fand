package exitpool

import (
	"testing"

	"github.com/bsfdsagfadg/vertex/internal/node/nodestore"
)

// TestProbeDedup_SingleFlightPerNode 同一节点同时只允许一次探测（自动与手动共用）。
func TestProbeDedup_SingleFlightPerNode(t *testing.T) {
	mgr := NewManager(nil, nil, Hooks{}, nil)

	if !mgr.TryBeginProbe("u1") {
		t.Fatal("首次应能取得探测权")
	}
	if mgr.TryBeginProbe("u1") {
		t.Fatal("同一节点不得重复取得探测权（重复触发保护）")
	}
	if !mgr.ProbeInFlight("u1") {
		t.Fatal("占用期间应报告探测中")
	}
	// 不同节点互不影响。
	if !mgr.TryBeginProbe("u2") {
		t.Fatal("不同节点应可并发探测")
	}
	mgr.EndProbe("u1")
	if mgr.ProbeInFlight("u1") {
		t.Fatal("EndProbe 后不应再报告探测中")
	}
	if !mgr.TryBeginProbe("u1") {
		t.Fatal("EndProbe 后应能重新取得探测权")
	}
	mgr.EndProbe("u1")
	mgr.EndProbe("u2")

	// Reset 应清空进行中集合，避免残留把节点永久挡在探测之外。
	if !mgr.TryBeginProbe("u1") {
		t.Fatal("前置：u1 应可占用")
	}
	mgr.Reset()
	if mgr.ProbeInFlight("u1") {
		t.Fatal("Reset 应清空探测进行中集合")
	}
}

// TestManualProbeFailure_KeepsDisabledNoPromotion 手动探测失败（Source=admin_single）
// 不写不可恢复来源、也不参与"永久禁用"升级：节点仍保持 health 禁用，
// AutoProbeFailStreak 不增长（那是自动探测连续失败才有的语义）。
func TestManualProbeFailure_KeepsDisabledNoPromotion(t *testing.T) {
	mgr := NewManager(nil, nil, Hooks{}, func() int { return 1 }) // 阈值 1：若误按自动语义早就转永久
	mgr.seedUnsafe([]Node{{RawURI: "u1", Name: "n1"}}, nil)       //nolint:exhaustruct

	// 先让它进入 health 禁用。
	mgr.ReportProbe("u1", ProbeResult{OK: false, ErrStr: "dial tcp: connection refused"})
	if src := mgr.LoadNodes()[0].DisableSource; src != nodestore.DisableSourceHealth {
		t.Fatalf("前置：应为 health 禁用, got %q", src)
	}

	// 手动探测连续失败多次：不得改写来源、不得转永久。
	for i := 0; i < 3; i++ {
		mgr.ReportProbe("u1", ProbeResult{
			OK: false, ErrStr: "dial tcp: connection refused",
			Source: nodestore.ProbeSourceAdminSingle,
		})
	}
	n := mgr.LoadNodes()[0]
	if !n.Disabled {
		t.Fatal("手动探测失败应保持禁用")
	}
	if n.DisableSource != nodestore.DisableSourceHealth {
		t.Fatalf("手动探测失败不得改写禁用来源, got %q", n.DisableSource)
	}
	if h := mgr.LoadHealth()["u1"]; h.AutoProbeFailStreak != 0 {
		t.Errorf("手动探测不应累计自动探测连败, got %d", h.AutoProbeFailStreak)
	}
	if !mgr.HealthAutoDisabledURIs()["u1"] {
		t.Error("手动探测失败后节点仍应可被自动探测恢复")
	}
}

// TestManualProbeSuccess_Recovers 手动探测成功经与自动探测同一恢复路径解除 health 禁用。
func TestManualProbeSuccess_Recovers(t *testing.T) {
	mgr := NewManager(nil, nil, Hooks{}, func() int { return 2 })
	mgr.seedUnsafe([]Node{{RawURI: "u1", Name: "n1"}}, nil) //nolint:exhaustruct

	mgr.ReportProbe("u1", ProbeResult{OK: false, ErrStr: "dial tcp: connection refused"})
	mgr.ReportProbe("u1", ProbeResult{OK: true, Ms: 30, Source: nodestore.ProbeSourceAdminSingle})

	if mgr.LoadNodes()[0].Disabled {
		t.Fatal("手动探测成功应恢复节点")
	}
	if src := mgr.DisableSourceOf("u1"); src != "" {
		t.Fatalf("恢复后禁用来源应为空, got %q", src)
	}
}

// TestManualProbeSuccess_DoesNotRecoverNonAutoRecoverable 手动探测成功也不得放开
// 人工/协议不支持等不可自动恢复的禁用——与自动探测同一判定标准。
func TestManualProbeSuccess_DoesNotRecoverNonAutoRecoverable(t *testing.T) {
	mgr := NewManager(nil, nil, Hooks{}, nil)
	mgr.seedUnsafe([]Node{{RawURI: "u1", Name: "n1"}}, nil) //nolint:exhaustruct
	mgr.BatchDisableWithSource([]string{"u1"}, nodestore.DisableSourceUnsupported, "协议不支持", string(nodestore.FailureUnsupported))

	mgr.ReportProbe("u1", ProbeResult{OK: true, Ms: 30, Source: nodestore.ProbeSourceAdminSingle})
	if !mgr.LoadNodes()[0].Disabled {
		t.Fatal("协议不支持的禁用不得被手动探测成功放开")
	}
}

// TestNodeState 校验池内存在性与禁用状态查询（手动探测入口的校验依据）。
func TestNodeState(t *testing.T) {
	mgr := NewManager(nil, nil, Hooks{}, func() int { return 2 })
	mgr.seedUnsafe([]Node{{RawURI: "u1", Name: "n1"}}, nil) //nolint:exhaustruct

	if exists, disabled := mgr.NodeState("u1"); !exists || disabled {
		t.Errorf("u1 应存在且未禁用, got exists=%v disabled=%v", exists, disabled)
	}
	if exists, _ := mgr.NodeState("nope"); exists {
		t.Error("不存在的节点应返回 exists=false")
	}

	mgr.ReportProbe("u1", ProbeResult{OK: false, ErrStr: "dial tcp: connection refused"})
	if exists, disabled := mgr.NodeState("u1"); !exists || !disabled {
		t.Errorf("u1 禁用后应 exists=true disabled=true, got exists=%v disabled=%v", exists, disabled)
	}
}

// TestDisabledURIs 枚举全部禁用节点（不分来源），供批量探测取目标集。
func TestDisabledURIs(t *testing.T) {
	mgr := NewManager(nil, nil, Hooks{}, func() int { return 2 })
	mgr.seedUnsafe([]Node{ //nolint:exhaustruct
		{RawURI: "u1", Name: "n1"},
		{RawURI: "u2", Name: "n2"},
		{RawURI: "u3", Name: "n3"},
	}, nil)

	if got := mgr.DisabledURIs(); len(got) != 0 {
		t.Fatalf("初始应无禁用节点, got %v", got)
	}

	// u1 健康禁用；u2 人工禁用。
	mgr.ReportProbe("u1", ProbeResult{OK: false, ErrStr: "dial tcp: connection refused"})
	mgr.BatchUpdateNodesDisabled([]string{"u2"}, true)

	got := mgr.DisabledURIs()
	if len(got) != 2 {
		t.Fatalf("应枚举 2 个禁用节点, got %v", got)
	}
	seen := map[string]bool{}
	for _, u := range got {
		seen[u] = true
	}
	if !seen["u1"] || !seen["u2"] || seen["u3"] {
		t.Fatalf("枚举集合不正确: %v", got)
	}
	// 健康禁用子集应只含 u1。
	auto := mgr.HealthAutoDisabledURIs()
	if len(auto) != 1 || !auto["u1"] {
		t.Fatalf("健康禁用子集应只含 u1, got %v", auto)
	}
}
