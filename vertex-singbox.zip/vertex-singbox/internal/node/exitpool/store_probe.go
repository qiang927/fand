package exitpool

// ---- 单节点探测互斥（自动探测与手动探测共用）----
//
// 探测会真实发起一次 reCAPTCHA token 抓取、单节点可能持续数秒。同一节点被并发重复
// 探测会重复累计失败计数（提前触阈转永久禁用）、并额外占用出口带宽，因此用一个
// per-node 的进行中集合把"判定 + 占用"合成一次加锁操作。它与批量测速/自动探测共享的
// 全局独占令牌（TryAcquireTestRun）互补：后者防的是全局互斥，前者防的是同一节点重复。

// TryBeginProbe 尝试为 uri 标记一次进行中的探测；若该节点已在探测中返回 false。
func (m *Manager) TryBeginProbe(uri string) bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.probeInFlight == nil {
		m.probeInFlight = make(map[string]struct{})
	}
	if _, busy := m.probeInFlight[uri]; busy {
		return false
	}
	m.probeInFlight[uri] = struct{}{}
	return true
}

// EndProbe 清除 uri 的进行中标记（须与 TryBeginProbe 成对调用）。
func (m *Manager) EndProbe(uri string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	delete(m.probeInFlight, uri)
}

// ProbeInFlight 报告 uri 是否正在被探测（自动或手动）。
func (m *Manager) ProbeInFlight(uri string) bool {
	m.mu.RLock()
	defer m.mu.RUnlock()
	_, busy := m.probeInFlight[uri]
	return busy
}

// NodeState 返回 uri 是否存在于节点池，以及当前是否处于禁用状态。
// 供管理端手动探测校验：只允许探测"池内且已禁用"的节点，避免把接口变成
// 任意目标 URI 的服务端出站探测入口。
func (m *Manager) NodeState(uri string) (exists, disabled bool) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.ensureLoaded()
	idx := m.nodeByURISeek(uri)
	if idx < 0 {
		return false, false
	}
	return true, m.nodeList[idx].Disabled
}

// DisabledURIs 返回当前全部禁用节点的 URI 快照（不分来源）。
// 供管理端"批量探测全部禁用节点"枚举目标：人工/admin_test/permanent/unsupported
// 来源也在其中——探测成功只会放开 health 来源，其余仅记录可达性与故障原因。
func (m *Manager) DisabledURIs() []string {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.ensureLoaded()
	out := make([]string, 0, len(m.nodeList))
	for _, n := range m.nodeList {
		if n.Disabled {
			out = append(out, n.RawURI)
		}
	}
	return out
}
