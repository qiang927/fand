package api

import (
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/bsfdsagfadg/vertex/internal/infra/db"
	"github.com/bsfdsagfadg/vertex/internal/infra/stats"
)

// TestOpenAIChat_TTFBVisibleWhileInFlight OpenAI 兼容端点此前从不注册上游首字节回调，
// 导致在途/TUI 的「首字」列只在完成时才出现。此用例断言在途期间首字已就绪。
func TestOpenAIChat_TTFBVisibleWhileInFlight(t *testing.T) {
	release := make(chan struct{})
	var releaseOnce sync.Once
	releaseFn := func() { releaseOnce.Do(func() { close(release) }) }
	defer releaseFn()

	contentFrame := `{"results":[{"data":{"ui":{"streamGenerateContentAnonymous":{"candidates":[{"content":{"parts":[{"text":"hello"}],"role":"model"},"finishReason":"FINISH_REASON_UNSPECIFIED"}]}}}}]}`
	mock := func(w http.ResponseWriter, _ *http.Request) {
		time.Sleep(30 * time.Millisecond) // 让上游首字可测（>1ms）
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(contentFrame))
		if fl, ok := w.(http.Flusher); ok {
			fl.Flush()
		}
		<-release // 保持请求在途，供测试在"数据传输"中读取在途快照
	}

	store, err := db.NewMemoryStore()
	if err != nil {
		t.Fatalf("NewMemoryStore: %v", err)
	}
	defer func() { _ = store.Close() }()
	stats.Close()
	stats.Init(store)
	defer stats.Close()

	fx := newTestServerCustomMock(t, mock, nil)

	go func() {
		body := `{"model":"gemini-2.5-flash","messages":[{"role":"user","content":"hi"}]}`
		req, _ := http.NewRequest(http.MethodPost,
			fx.server.URL+"/v1/chat/completions?key=sk-test-key", strings.NewReader(body))
		req.Header.Set("Content-Type", "application/json")
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			return
		}
		defer func() { _ = resp.Body.Close() }()
		_, _ = io.Copy(io.Discard, resp.Body)
	}()

	deadline := time.Now().Add(3 * time.Second)
	var gotTTFB int64
	var lastSnap string
	for time.Now().Before(deadline) {
		for _, a := range stats.ActiveRequests() {
			lastSnap = fmt.Sprintf("state=%s upstreamTTFB=%d", a.Status, a.UpstreamTTFBMs)
			if a.UpstreamTTFBMs > gotTTFB {
				gotTTFB = a.UpstreamTTFBMs
			}
		}
		if gotTTFB > 0 {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}

	if gotTTFB <= 0 {
		t.Fatalf("OpenAI 端点在途期间上游首字未就绪（%s）", lastSnap)
	}
}
