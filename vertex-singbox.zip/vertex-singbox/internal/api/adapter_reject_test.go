package api

import (
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"sync/atomic"
	"testing"

	"github.com/bsfdsagfadg/vertex/internal/engine/transform"
	"github.com/bsfdsagfadg/vertex/internal/infra/config"
	"github.com/bsfdsagfadg/vertex/internal/infra/db"
	"github.com/bsfdsagfadg/vertex/internal/infra/stats"
)

// TestOpenAIChat_AdapterRejected_OpenAISchema_NoUpstreamCall Issue #14：不支持的输入
// （远程图片 URL）必须明确 400 + OpenAI error schema，并带 param 定位；
// 且**不得发起任何真实上游请求**（请求级错误，与上游失败分离）。
func TestOpenAIChat_AdapterRejected_OpenAISchema_NoUpstreamCall(t *testing.T) {
	var upstreamHits int32
	mock := func(w http.ResponseWriter, _ *http.Request) {
		atomic.AddInt32(&upstreamHits, 1)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(`[]`))
	}
	fx := newTestServerCustomMock(t, mock, func(c *config.AppConfig) {
		c.MaxRetries = 0
		c.ParallelPoolEnabled = false
	})

	body := `{"model":"gemini-2.5-flash","messages":[{"role":"user","content":[` +
		`{"type":"text","text":"看图"},` +
		`{"type":"image_url","image_url":{"url":"https://example.com/a.png"}}]}]}`
	req, _ := http.NewRequest(http.MethodPost, fx.server.URL+"/v1/chat/completions", strings.NewReader(body))
	req.Header.Set("Authorization", "Bearer sk-test-key")
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("request failed: %v", err)
	}
	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusBadRequest {
		t.Fatalf("status=%d, want 400", resp.StatusCode)
	}
	var out transform.OpenAIErrorResponse
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
		t.Fatalf("错误体应为 OpenAI schema: %v", err)
	}
	if out.Error.Type != transform.OpenAIErrTypeInvalidRequest {
		t.Errorf("error.type=%q, want %q", out.Error.Type, transform.OpenAIErrTypeInvalidRequest)
	}
	if out.Error.Param != "messages[0].content[1].image_url.url" {
		t.Errorf("error.param=%q，应指向出错字段", out.Error.Param)
	}
	if !strings.Contains(out.Error.Message, "unsupported image URL") {
		t.Errorf("error.message=%q", out.Error.Message)
	}
	if got := atomic.LoadInt32(&upstreamHits); got != 0 {
		t.Fatalf("适配层拒绝不得发起真实上游请求，实得 %d 次", got)
	}
}

// TestWithRecover_OpenAIPathUsesOpenAISchema /v1/chat/completions 上 panic 必须返回
// OpenAI error schema，而不是 Gemini 形状（Issue #14）。
func TestWithRecover_OpenAIPathUsesOpenAISchema(t *testing.T) {
	mw := &middleware{} //nolint:exhaustruct
	rec := httptest.NewRecorder()
	mw.withRecover(http.HandlerFunc(func(http.ResponseWriter, *http.Request) {
		panic("boom")
	})).ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/v1/chat/completions", nil))

	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("status=%d, want 500", rec.Code)
	}
	var out transform.OpenAIErrorResponse
	if err := json.Unmarshal(rec.Body.Bytes(), &out); err != nil {
		t.Fatalf("panic 响应应为 OpenAI schema: %v（body=%s）", err, rec.Body.String())
	}
	if out.Error.Type != transform.OpenAIErrTypeServer || out.Error.Code != "server_error" {
		t.Errorf("error=%+v, want server_error", out.Error)
	}
}

// TestWithRecover_GeminiPathKeepsGeminiSchema Gemini 路径的 panic 响应保持 Gemini schema。
func TestWithRecover_GeminiPathKeepsGeminiSchema(t *testing.T) {
	mw := &middleware{} //nolint:exhaustruct
	rec := httptest.NewRecorder()
	mw.withRecover(http.HandlerFunc(func(http.ResponseWriter, *http.Request) {
		panic("boom")
	})).ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/v1beta/models/gemini-2.5-flash:generateContent", nil))

	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("status=%d, want 500", rec.Code)
	}
	var body map[string]any
	if err := json.Unmarshal(rec.Body.Bytes(), &body); err != nil {
		t.Fatalf("body 不是 JSON: %v", err)
	}
	errObj, _ := body["error"].(map[string]any)
	if errObj == nil {
		t.Fatalf("缺少 error 对象: %s", rec.Body.String())
	}
	if _, isOpenAIShape := errObj["type"]; isOpenAIShape {
		t.Errorf("Gemini 路径不得返回 OpenAI schema: %s", rec.Body.String())
	}
	if _, ok := errObj["code"]; !ok {
		t.Errorf("Gemini 路径应保留 Gemini schema（含 error.code）: %s", rec.Body.String())
	}
}

// TestOpenAIChat_UnresolvableToolResult_Rejected Issue #14 P0：无法可靠恢复的 tool result
// 必须整体拒绝——外部可观察行为：400 + OpenAI schema + param、上游零调用、节点健康零触碰。
func TestOpenAIChat_UnresolvableToolResult_Rejected(t *testing.T) {
	var upstreamHits int32
	mock := func(w http.ResponseWriter, _ *http.Request) {
		atomic.AddInt32(&upstreamHits, 1)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(`[]`))
	}
	fx := newTestServerCustomMock(t, mock, func(c *config.AppConfig) {
		c.MaxRetries = 0
		c.ParallelPoolEnabled = false
	})

	cases := []struct{ name, body string }{
		{"id 缺失且无 name",
			`{"model":"gemini-2.5-flash","messages":[{"role":"user","content":"查天气"},{"role":"tool","content":"晴"}]}`},
		{"id 不匹配且无 name",
			`{"model":"gemini-2.5-flash","messages":[{"role":"user","content":"查天气"},{"role":"tool","tool_call_id":"call_missing","content":"晴"}]}`},
		{"id 不匹配但带 name（不得按 name 回退）",
			`{"model":"gemini-2.5-flash","messages":[{"role":"user","content":"查天气"},{"role":"tool","tool_call_id":"call_missing","name":"get_weather","content":"晴"}]}`},
		{"id 缺失但带 name（不得按 name 回退）",
			`{"model":"gemini-2.5-flash","messages":[{"role":"user","content":"查天气"},{"role":"tool","name":"get_weather","content":"晴"}]}`},
		{"合法+非法混排（不得只发合法部分）",
			`{"model":"gemini-2.5-flash","messages":[` +
				`{"role":"user","content":"查天气"},` +
				`{"role":"assistant","tool_calls":[{"id":"call_ok","type":"function","function":{"name":"get_weather","arguments":"{}"}}]},` +
				`{"role":"tool","tool_call_id":"call_ok","content":"晴"},` +
				`{"role":"tool","tool_call_id":"call_missing","content":"x"}]}`},
		{"assistant tool_call 缺函数名",
			`{"model":"gemini-2.5-flash","messages":[` +
				`{"role":"user","content":"查天气"},` +
				`{"role":"assistant","tool_calls":[{"id":"call_1","type":"function","function":{}}]}]}`},
	}

	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			req, _ := http.NewRequest(http.MethodPost, fx.server.URL+"/v1/chat/completions", strings.NewReader(c.body))
			req.Header.Set("Authorization", "Bearer sk-test-key")
			req.Header.Set("Content-Type", "application/json")
			resp, err := http.DefaultClient.Do(req)
			if err != nil {
				t.Fatalf("request failed: %v", err)
			}
			defer func() { _ = resp.Body.Close() }()
			if resp.StatusCode != http.StatusBadRequest {
				t.Fatalf("status=%d, want 400", resp.StatusCode)
			}
			var out transform.OpenAIErrorResponse
			if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
				t.Fatalf("应返回 OpenAI error schema: %v", err)
			}
			if out.Error.Type != transform.OpenAIErrTypeInvalidRequest {
				t.Errorf("error.type=%q, want invalid_request_error", out.Error.Type)
			}
			if out.Error.Param == "" {
				t.Error("error.param 应指向出错字段")
			}
		})
	}

	if got := atomic.LoadInt32(&upstreamHits); got != 0 {
		t.Fatalf("请求级拒绝不得调用上游，实得 %d 次", got)
	}
	if h := fx.exitMgr.LoadHealth(); len(h) != 0 {
		t.Errorf("不得产生节点健康记录: %+v", h)
	}
	if uris := fx.exitMgr.HealthAutoDisabledURIs(); len(uris) != 0 {
		t.Errorf("不得进入自动探测名单: %v", uris)
	}
}

// TestOpenAIChat_ResolvableToolResult_Accepted 对照：tool_call_id 正常匹配时正常转换
// 并送达上游 functionResponse（不得因新校验误伤合法请求）。
func TestOpenAIChat_ResolvableToolResult_Accepted(t *testing.T) {
	var mu sync.Mutex
	var upstreamBody string
	mock := func(w http.ResponseWriter, r *http.Request) {
		b, _ := io.ReadAll(r.Body)
		mu.Lock()
		upstreamBody = string(b)
		mu.Unlock()
		p := `{"candidates":[{"content":{"parts":[{"text":"ok"}],"role":"model"},"finishReason":"STOP"}]}`
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(`[{"results":[{"data":{"ui":{"streamGenerateContentAnonymous":` + p + `}}}]}]`))
	}
	fx := newTestServerCustomMock(t, mock, func(c *config.AppConfig) {
		c.MaxRetries = 0
		c.ParallelPoolEnabled = false
	})

	body := `{"model":"gemini-2.5-flash","messages":[` +
		`{"role":"user","content":"查天气"},` +
		`{"role":"assistant","tool_calls":[{"id":"call_ok","type":"function",` +
		`"function":{"name":"get_weather","arguments":"{\"city\":\"Paris\"}"}}]},` +
		`{"role":"tool","tool_call_id":"call_ok","content":"sunny"}]}`
	req, _ := http.NewRequest(http.MethodPost, fx.server.URL+"/v1/chat/completions", strings.NewReader(body))
	req.Header.Set("Authorization", "Bearer sk-test-key")
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("request failed: %v", err)
	}
	defer func() { _ = resp.Body.Close() }()
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("status=%d, want 200（合法工具往返不得被拒）", resp.StatusCode)
	}
	mu.Lock()
	got := upstreamBody
	mu.Unlock()
	if !strings.Contains(got, "functionResponse") || !strings.Contains(got, "sunny") {
		t.Errorf("上游未收到 functionResponse: %s", truncateTail(got, 400))
	}
}

// TestOpenAIChat_AdapterRejected_StatsIsolated 统计闭环：适配层拒绝记为独立结果分类，
// 不计入上游成功/失败（实时计数器外部可观察）。
func TestOpenAIChat_AdapterRejected_StatsIsolated(t *testing.T) {
	store, err := db.NewMemoryStore()
	if err != nil {
		t.Fatalf("NewMemoryStore: %v", err)
	}
	defer func() { _ = store.Close() }()
	stats.Close()
	stats.Init(store)
	defer stats.Close()

	mock := func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(`[]`))
	}
	fx := newTestServerCustomMock(t, mock, func(c *config.AppConfig) {
		c.MaxRetries = 0
		c.ParallelPoolEnabled = false
	})

	body := `{"model":"gemini-2.5-flash","messages":[{"role":"user","content":[` +
		`{"type":"image_url","image_url":{"url":"https://example.com/a.png"}}]}]}`
	req, _ := http.NewRequest(http.MethodPost, fx.server.URL+"/v1/chat/completions", strings.NewReader(body))
	req.Header.Set("Authorization", "Bearer sk-test-key")
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("request failed: %v", err)
	}
	defer func() { _ = resp.Body.Close() }()
	if resp.StatusCode != http.StatusBadRequest {
		t.Fatalf("status=%d, want 400", resp.StatusCode)
	}

	snap := stats.Snapshot()
	if snap["adapter_rejected"] != int64(1) {
		t.Errorf("adapter_rejected=%v, want 1（应记为独立结果分类）", snap["adapter_rejected"])
	}
	if snap["errors"] != int64(0) {
		t.Errorf("errors=%v, want 0（适配层拒绝不得计入上游失败）", snap["errors"])
	}
	if snap["success"] != int64(0) {
		t.Errorf("success=%v, want 0", snap["success"])
	}
}
