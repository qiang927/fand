package api

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/bsfdsagfadg/vertex/internal/engine/vertex"
	"github.com/bsfdsagfadg/vertex/internal/infra/db"
	"github.com/bsfdsagfadg/vertex/internal/infra/stats"
)

// TestFailureStatus_Classification 覆盖取消状态码分类：
// 非管理员取消（ctx 结束）→ 498；管理员停止 → 499；其余按 VertexError 自身码（上游取消 502）。
func TestFailureStatus_Classification(t *testing.T) {
	initTestStatsForSubstitute(t)

	// 普通上游错误：按自身 Code（502 网络/上游取消）。
	if code, _ := failureStatus(context.Background(), "no-such-req", vertex.NewNetworkError(errors.New("connection reset by peer"))); code != 502 {
		t.Errorf("上游取消应落 502, got %d", code)
	}

	// 父上下文被取消 → 498。
	canceledCtx, cancel := context.WithCancel(context.Background())
	cancel()
	if code, _ := failureStatus(canceledCtx, "no-such-req", vertex.NewInternalError("context canceled", nil)); code != db.StatusClientCanceled {
		t.Errorf("客户端取消应落 %d, got %d", db.StatusClientCanceled, code)
	}

	// 总超时（DeadlineExceeded）同样归 498：它是程序侧请求级截止，不是上游故障。
	deadCtx, deadCancel := context.WithTimeout(context.Background(), -time.Second)
	defer deadCancel()
	if code, _ := failureStatus(deadCtx, "no-such-req", vertex.NewContextError(context.DeadlineExceeded)); code != db.StatusClientCanceled {
		t.Errorf("请求级超时应落 %d, got %d", db.StatusClientCanceled, code)
	}

	// 管理员停止优先于 ctx 取消 → 499。
	const reqID = "req-fs-admin"
	stats.StartReq(reqID, "m", "", "k", false)
	defer stats.StopReq(reqID)
	_, adminCancel := context.WithCancel(context.Background())
	defer adminCancel()
	stats.SetReqCancel(reqID, adminCancel)
	stats.CancelReq(reqID)
	if code, reason := failureStatus(canceledCtx, reqID, vertex.NewInternalError("context canceled", nil)); code != db.StatusAdminCanceled {
		t.Errorf("管理员停止应落 %d, got %d（%s）", db.StatusAdminCanceled, code, reason)
	}
}
