package api

import (
	"encoding/json"
	"io"
	"net/http"
	"strings"
	"testing"
	"time"

	"github.com/bsfdsagfadg/vertex/internal/infra/config"
)

// openAIStreamFixture 造一个 /v1/chat/completions 流式测试服务（默认关闭聚合）。
func openAIStreamFixture(t *testing.T, cfgMod func(*config.AppConfig)) *testFixture {
	t.Helper()
	return newTestServerCustomMock(t, openaiTextStreamingUpstream([]string{"你好", "世界"}, 5*time.Millisecond),
		func(c *config.AppConfig) {
			c.MaxRetries = 0
			c.ParallelPoolEnabled = false
			if cfgMod != nil {
				cfgMod(c)
			}
		})
}

// openAIChatStreamBody 发一次流式请求并返回原始响应体。
func openAIChatStreamBody(t *testing.T, fx *testFixture, body string) string {
	t.Helper()
	req, _ := http.NewRequest(http.MethodPost, fx.server.URL+"/v1/chat/completions", strings.NewReader(body))
	req.Header.Set("Authorization", "Bearer sk-test-key")
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("request failed: %v", err)
	}
	defer func() { _ = resp.Body.Close() }()
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("status=%d, want 200", resp.StatusCode)
	}
	return readAllString(t, resp)
}

func openAIChatStream(t *testing.T, fx *testFixture, model string) string {
	t.Helper()
	return openAIChatStreamBody(t, fx,
		`{"model":"`+model+`","messages":[{"role":"user","content":"hi"}],"stream":true}`)
}

// openAIStreamFrames 解析 SSE data 帧（剔除 [DONE]）并做收尾断言。
func openAIStreamFrames(t *testing.T, raw string) []map[string]any {
	t.Helper()
	if !strings.HasSuffix(raw, "data: [DONE]\n\n") {
		t.Fatalf("流式响应必须以 data: [DONE] 收尾，实得结尾: %q", truncateTail(raw, 120))
	}
	var out []map[string]any
	for _, line := range strings.Split(raw, "\n") {
		if !strings.HasPrefix(line, "data: ") {
			continue
		}
		payload := strings.TrimPrefix(line, "data: ")
		if payload == "[DONE]" {
			continue
		}
		var obj map[string]any
		if err := json.Unmarshal([]byte(payload), &obj); err != nil {
			t.Fatalf("data 帧不是合法 JSON: %q (%v)", payload, err)
		}
		out = append(out, obj)
	}
	if len(out) == 0 {
		t.Fatalf("未收到任何 data 帧: %q", truncateTail(raw, 200))
	}
	return out
}

// assertOpenAIChunkShape 断言流式帧形状合规（Issue #13）：
// 每帧必须是 chat.completion.chunk、带 choices[].delta、绝不出现 message。
// 返回拼接后的 delta 正文与最后一次非空 finish_reason。
func assertOpenAIChunkShape(t *testing.T, frames []map[string]any) (content, finish string) {
	t.Helper()
	var sb strings.Builder
	for _, obj := range frames {
		if obj["object"] != "chat.completion.chunk" {
			t.Errorf("object=%v, want chat.completion.chunk（聚合交付也必须是流式帧形状）", obj["object"])
		}
		choices, _ := obj["choices"].([]any)
		if len(choices) == 0 {
			continue // usage 帧
		}
		ch, _ := choices[0].(map[string]any)
		if _, has := ch["message"]; has {
			t.Errorf("流式帧不得出现 message（应为 delta）: %v", ch)
		}
		delta, ok := ch["delta"].(map[string]any)
		if !ok {
			t.Errorf("流式帧缺少 delta: %v", ch)
			continue
		}
		if s, _ := delta["content"].(string); s != "" {
			sb.WriteString(s)
		}
		if fr, _ := ch["finish_reason"].(string); fr != "" {
			finish = fr
		}
	}
	return sb.String(), finish
}

// TestOpenAIEndpoint_AggregateStream_EmitsChunkFrames 全局「聚合流式」下，
// stream:true 必须以 chat.completion.chunk + delta 交付（Issue #13 主回归）。
func TestOpenAIEndpoint_AggregateStream_EmitsChunkFrames(t *testing.T) {
	fx := openAIStreamFixture(t, func(c *config.AppConfig) { c.AggregateStream = true })
	frames := openAIStreamFrames(t, openAIChatStream(t, fx, "gemini-2.5-flash"))

	content, finish := assertOpenAIChunkShape(t, frames)
	if content != "你好世界" {
		t.Errorf("delta 正文=%q, want 你好世界（内容必须走 delta.content）", content)
	}
	if finish != "stop" {
		t.Errorf("finish_reason=%q, want stop", finish)
	}
	// 未请求 include_usage：任何帧都不得携带 usage。
	for _, f := range frames {
		if _, has := f["usage"]; has {
			t.Errorf("未请求 include_usage 时不得返回 usage: %v", f)
		}
	}
}

// TestOpenAIEndpoint_FakeNonStreamVariant_EmitsChunkFrames 「假非流-」前缀是另一条
// 聚合触发路径，同样必须是 chunk/delta 形状。
func TestOpenAIEndpoint_FakeNonStreamVariant_EmitsChunkFrames(t *testing.T) {
	fx := openAIStreamFixture(t, nil) // 不开 aggregate_stream，靠前缀触发聚合
	frames := openAIStreamFrames(t, openAIChatStream(t, fx, "假非流-gemini-2.5-flash"))

	content, finish := assertOpenAIChunkShape(t, frames)
	if content != "你好世界" {
		t.Errorf("delta 正文=%q, want 你好世界", content)
	}
	if finish != "stop" {
		t.Errorf("finish_reason=%q, want stop", finish)
	}
}

// TestOpenAIEndpoint_AggregateStream_IncludeUsage usage 只在 include_usage 时
// 以独立帧（choices: []）返回。
func TestOpenAIEndpoint_AggregateStream_IncludeUsage(t *testing.T) {
	fx := openAIStreamFixture(t, func(c *config.AppConfig) { c.AggregateStream = true })
	raw := openAIChatStreamBody(t, fx,
		`{"model":"gemini-2.5-flash","messages":[{"role":"user","content":"hi"}],"stream":true,`+
			`"stream_options":{"include_usage":true}}`)

	frames := openAIStreamFrames(t, raw)
	assertOpenAIChunkShape(t, frames)

	sawUsageFrame := false
	for _, f := range frames {
		choices, _ := f["choices"].([]any)
		if len(choices) == 0 {
			if _, has := f["usage"]; has {
				sawUsageFrame = true
			}
		}
	}
	if !sawUsageFrame {
		t.Error("include_usage 时应返回独立的 usage 帧（choices: []）")
	}
}

// TestOpenAIEndpoint_AggregateStream_ToolCalls 聚合模式下工具调用必须落在
// delta.tool_calls（而非 message.tool_calls）。
func TestOpenAIEndpoint_AggregateStream_ToolCalls(t *testing.T) {
	mock := func(w http.ResponseWriter, _ *http.Request) {
		payload := `{"candidates":[{"content":{"parts":[{"functionCall":{"name":"get_weather","args":{"city":"Paris"}}}],"role":"model"},"finishReason":"STOP"}]}`
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte(`[{"results":[{"data":{"ui":{"streamGenerateContentAnonymous":` + payload + `}}}]}]`))
	}
	fx := newTestServerCustomMock(t, mock, func(c *config.AppConfig) {
		c.MaxRetries = 0
		c.ParallelPoolEnabled = false
		c.AggregateStream = true
	})
	raw := openAIChatStreamBody(t, fx,
		`{"model":"gemini-2.5-flash","messages":[{"role":"user","content":"weather?"}],`+
			`"tools":[{"type":"function","function":{"name":"get_weather","parameters":{"type":"object"}}}],"stream":true}`)

	sawTool := false
	for _, f := range openAIStreamFrames(t, raw) {
		choices, _ := f["choices"].([]any)
		if len(choices) == 0 {
			continue
		}
		ch, _ := choices[0].(map[string]any)
		if _, has := ch["message"]; has {
			t.Errorf("流式帧不得出现 message: %v", ch)
		}
		if delta, ok := ch["delta"].(map[string]any); ok {
			if calls, ok := delta["tool_calls"].([]any); ok && len(calls) > 0 {
				sawTool = true
			}
		}
	}
	if !sawTool {
		t.Errorf("聚合模式工具调用应出现在 delta.tool_calls，实得: %s", truncateTail(raw, 300))
	}
}

// TestOpenAIEndpoint_AggregateStream_SafetyEmitsContentFilter 聚合 + 安全拦截：
// 以 OpenAI 流式的 content_filter finish 语义交付（chunk 帧、无正文）。
func TestOpenAIEndpoint_AggregateStream_SafetyEmitsContentFilter(t *testing.T) {
	mock := func(w http.ResponseWriter, r *http.Request) {
		_, _ = io.ReadAll(r.Body)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusBadRequest)
		_, _ = w.Write([]byte(`{"error":{"message":"PROHIBITED_CONTENT"}}`))
	}
	fx := newTestServerCustomMock(t, mock, func(c *config.AppConfig) {
		c.MaxRetries = 0
		c.ParallelPoolEnabled = false
		c.AggregateStream = true
	})

	frames := openAIStreamFrames(t, openAIChatStream(t, fx, "gemini-2.5-flash"))
	content, finish := assertOpenAIChunkShape(t, frames)
	if content != "" {
		t.Errorf("安全拦截不应交付正文, got %q", content)
	}
	if finish != "content_filter" {
		t.Errorf("finish_reason=%q, want content_filter", finish)
	}
}
