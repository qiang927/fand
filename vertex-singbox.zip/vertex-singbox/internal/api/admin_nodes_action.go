package api

import (
	"context"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"runtime"
	"strings"
	"sync"
	"time"

	"github.com/bsfdsagfadg/vertex/internal/infra/netx"
	"github.com/bsfdsagfadg/vertex/internal/infra/transport"
	"github.com/bsfdsagfadg/vertex/internal/node/exitpool"
	"github.com/bsfdsagfadg/vertex/internal/node/importer"
	"github.com/bsfdsagfadg/vertex/internal/node/nodestore"
)

const (
	singleNodeTestTimeoutSec = 15
)

// adminDisableAudit 依据失败的原始错误文本生成管理端禁用审计（类别 + 已脱敏原因）。
//
// 原因必须走分类器给出的 Detail（已由 nodestore.MaskSecrets 处理）：错误文本里常带完整 URL，
// 其 query 可能含 API Key/Cookie 等凭据（如 batchGraphql?key=...），而禁用原因会持久化
// 并原样下发到管理面板——直接拼接原始 errStr 等于把凭据写进数据库再展示出来。
func adminDisableAudit(prefix, errStr string) (class, reason string) {
	info := nodestore.ClassifyFailure(errStr)
	reason = prefix
	if info.Code != "" {
		reason += "（错误码 " + info.Code + "）"
	}
	if info.Detail != "" {
		reason += "：" + info.Detail
	}
	return string(info.Class), reason
}

// getBatchTestConcurrency 根据操作系统与 CPU 核心数自适应计算批量测速并发度，防止端口或调度过载
func getBatchTestConcurrency() int {
	concurrency := runtime.NumCPU() * 4
	if runtime.GOOS == "windows" {
		if concurrency > 30 {
			return 30
		}
		if concurrency < 10 {
			return 10
		}
		return concurrency
	}
	if concurrency > 50 {
		return 50
	}
	if concurrency < 10 {
		return 10
	}
	return concurrency
}

var (
	testAllCancel context.CancelFunc
	testAllMu     sync.Mutex
	testAllGen    uint64
)

// runBatchTasks 用有限 worker 池执行批量节点任务：生产者逐个投递任务并**在投递处**检查
// 暂停/终止，worker 只负责执行 fn；并发上限 = worker 数。
//
// 相比"为每个目标一次性建 goroutine、再在 goroutine 内各自等信号量"：目标很多时不会
// 产生大量"已创建但未运行"的任务，暂停/终止也能即时生效（生产者阻塞在 shouldStop 上，
// 任务缓冲仅为一个批次）。shouldStop 为 nil 时不检查（仅供不涉及暂停的场景）。
func runBatchTasks[T any](ctx context.Context, targets []T, concurrency int, shouldStop func() bool, fn func(T)) {
	if concurrency < 1 {
		concurrency = 1
	}
	tasks := make(chan T, concurrency)
	var wg sync.WaitGroup
	for i := 0; i < concurrency; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for tk := range tasks {
				if ctx.Err() != nil {
					return
				}
				fn(tk)
			}
		}()
	}
	defer func() {
		close(tasks)
		wg.Wait()
	}()

	for _, tk := range targets {
		if shouldStop != nil && shouldStop() {
			return
		}
		select {
		case tasks <- tk:
		case <-ctx.Done():
			return
		}
	}
}

func (adm *AdminHandler) adminGetTestProgress(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, adm.deps.Exit.GetTestProgress())
}

func (adm *AdminHandler) adminFetchSub(w http.ResponseWriter, r *http.Request) {
	var body struct {
		URL string `json:"url"`
	}
	if !adm.decodeAdminBody(w, r, &body) {
		return
	}
	log.Printf("[Admin] [FetchSub] 开始拉取订阅 URL: %s", body.URL)
	text, err := adm.fetchSubscriptionText(r.Context(), body.URL)
	if err != nil {
		log.Printf("[Admin] [FetchSub] 拉取失败: %v", err)
		writeJSON(w, http.StatusBadRequest, adminErr("拉取失败: "+err.Error()))
		return
	}

	newNodes := adm.deps.Imports.Parse(text)
	adm.markUnsupportedImports(newNodes)
	adm.deps.Exit.MergeNodes(newNodes)
	merged := make([]string, 0, len(newNodes))
	for _, cn := range newNodes {
		merged = append(merged, cn.RawURI)
	}
	adm.deps.IR.Prewarm(merged)
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "count": len(newNodes)})
}

// markUnsupportedImports 对导入结果中的不支持节点记录健康度失败原因
// （原副作用位于 importer.ParseImportedNodeLine，上移调用方以使 importer 回归纯解析库）。
func (adm *AdminHandler) markUnsupportedImports(newNodes []exitpool.Node) {
	for _, n := range newNodes {
		if !n.Disabled {
			continue
		}
		pn, err := adm.deps.IR.GetOrParse(n.RawURI)
		if err != nil || pn == nil {
			continue
		}
		adm.deps.Exit.RecordTest(n.RawURI, false, 0, "unsupported: "+pn.UnsupportedReason)
	}
}

func (adm *AdminHandler) adminTestAll(w http.ResponseWriter, _ *http.Request) {
	if adm.deps.Exit.IsTestRunning() {
		writeJSON(w, http.StatusConflict, adminErr("已有批量测试正在进行中，请先等待其结束或终止"))
		return
	}
	log.Printf("[Admin] [TestAll] 开始触发全局并发测速（基于 recaptchaToken 耗时）")
	go func() {
		list := adm.deps.Exit.LoadNodes()
		// 健康自动禁用的节点也必须纳入批量测试：它们已被摘出调度，请求路径触达不到，
		// 跳过它们会让"健康触发禁用"变成事实上的永久禁用（自动恢复无从触发）。
		// 人工禁用的节点不在其列（DisabledByHealth 标记已被人工禁用清掉）。
		autoDisabled := adm.deps.Exit.HealthAutoDisabledURIs()
		var enabledNodes []exitpool.Node
		for _, n := range list {
			if !n.Disabled || autoDisabled[n.RawURI] {
				enabledNodes = append(enabledNodes, n)
			}
		}
		totalEnabled := len(enabledNodes)
		if !adm.deps.Exit.StartTestProgress(totalEnabled) {
			log.Printf("[Admin] [TestAll] 已有批量测试正在进行中，拒绝重复触发")
			return
		}
		actualConcurrency := getBatchTestConcurrency()
		rounds := (totalEnabled + actualConcurrency - 1) / actualConcurrency
		dynamicTimeout := time.Duration(rounds*2)*singleNodeTestTimeoutSec*time.Second + 2*time.Minute
		if dynamicTimeout < 5*time.Minute {
			dynamicTimeout = 5 * time.Minute
		}
		log.Printf("[Admin] [TestAll] 加载待测节点数: %d/%d, 并发数: %d, 全局超时时间: %v", totalEnabled, len(list), actualConcurrency, dynamicTimeout)

		ctx, cancel := context.WithTimeout(context.Background(), dynamicTimeout)
		testAllMu.Lock()
		myGen := testAllGen + 1
		testAllGen = myGen
		if testAllCancel != nil {
			testAllCancel()
		}
		testAllCancel = cancel
		testAllMu.Unlock()
		defer func() {
			cancel()
			testAllMu.Lock()
			if testAllGen == myGen {
				testAllCancel = nil
			}
			testAllMu.Unlock()
		}()

		runBatchTasks(ctx, enabledNodes, actualConcurrency, adm.deps.Exit.CheckTestControl, func(node exitpool.Node) {
			// capability 早检查：不支持/解析失败的节点直接标为失败并禁用，记录真实错误原因
			if supported, reason, _ := adm.checkNodeSupport(node.RawURI); !supported {
				log.Printf("[Admin] [TestAll] 节点 %s (%s) 协议不支持或解析失败，标记禁用: %s", node.Name, node.Type, reason)
				adm.deps.Exit.ReportProbe(node.RawURI, exitpool.ProbeResult{
					OK: false, ErrStr: reason,
					Class: nodestore.FailureUnsupported, Source: nodestore.ProbeSourceUnsupported,
				})
				cls, auditReason := adminDisableAudit("协议不支持或解析失败", reason)
				adm.deps.Exit.BatchDisableWithSource([]string{node.RawURI}, nodestore.DisableSourceUnsupported, auditReason, cls)
				adm.deps.Exit.UpdateTestProgress(node.Name, false)
				return
			}

			start := time.Now()
			log.Printf("[Admin] [TestAll] 开始测试节点: %s (%s)", node.Name, node.Type)

			sess, err := adm.vc.Net().CreateSession(singleNodeTestTimeoutSec, node.RawURI, "admin-test-all")
			var testErr error
			if err == nil {
				defer sess.Close()
				testErr = adm.fetchRecaptchaTokenWithSess(ctx, sess)
			} else {
				testErr = err
			}

			duration := float64(time.Since(start).Milliseconds())
			if testErr != nil {
				log.Printf("[Admin] [TestAll] 节点 %s 测试失败: %v, 耗时: %.0fms", node.Name, testErr, duration)
			} else {
				log.Printf("[Admin] [TestAll] 节点 %s 测试成功, recaptcha 耗时: %.0fms", node.Name, duration)
			}
			success := testErr == nil
			// 批量测速失败 → 直接禁用（评审确认的既有语义，不走阈值）：管理员主动发起的
			// 全量测速，失败节点就该摘出去；来源记 admin_test 以便审计区分，
			// 且该来源不被自动探测恢复（需人工启用）。
			adm.deps.Exit.ReportProbe(node.RawURI, exitpool.ProbeResult{
				OK: success, Ms: duration, ErrStr: importer.ErrToStr(testErr),
				Source: nodestore.ProbeSourceAdminBatch,
			})
			if !success {
				cls, reason := adminDisableAudit("批量测速失败", importer.ErrToStr(testErr))
				adm.deps.Exit.BatchDisableWithSource([]string{node.RawURI}, nodestore.DisableSourceAdminTest, reason, cls)
			}
			adm.deps.Exit.UpdateTestProgress(node.Name, success)
		})
		adm.deps.Exit.FinishTestProgress()
		log.Printf("[Admin] [TestAll] 全局节点测试全部结束")
	}()
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (adm *AdminHandler) adminTestPause(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		adm.adminMethodNotAllowed(w)
		return
	}
	adm.deps.Exit.PauseTestProgress()
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (adm *AdminHandler) adminTestResume(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		adm.adminMethodNotAllowed(w)
		return
	}
	adm.deps.Exit.ResumeTestProgress()
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (adm *AdminHandler) adminTestTerminate(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		adm.adminMethodNotAllowed(w)
		return
	}
	adm.deps.Exit.TerminateTestProgress()
	testAllMu.Lock()
	if testAllCancel != nil {
		testAllCancel()
	}
	testAllMu.Unlock()
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (adm *AdminHandler) adminTestNode(w http.ResponseWriter, r *http.Request) {
	var body struct {
		RawURI         string  `json:"raw_uri"`
		AutoDisable    bool    `json:"auto_disable"`
		TimeoutSeconds float64 `json:"timeout_seconds"`
	}
	if !adm.decodeAdminBody(w, r, &body) {
		return
	}
	if body.TimeoutSeconds <= 0 {
		body.TimeoutSeconds = 25
	}
	timeout := time.Duration(body.TimeoutSeconds * float64(time.Second))
	ctx, cancel := context.WithTimeout(r.Context(), timeout)
	defer cancel()

	// capability 早检查：不支持/解析失败的节点直接标为失败并禁用，记录真实错误原因
	if supported, reason, _ := adm.checkNodeSupport(body.RawURI); !supported {
		log.Printf("[Admin] [TestNode] 节点 %s 协议不支持或解析失败，标记禁用: %s", adm.deps.Exit.NodeName(body.RawURI), reason)
		adm.deps.Exit.ReportProbe(body.RawURI, exitpool.ProbeResult{
			OK: false, ErrStr: reason,
			Class: nodestore.FailureUnsupported, Source: nodestore.ProbeSourceUnsupported,
		})
		unsupportedCls, unsupportedReason := adminDisableAudit("协议不支持或解析失败", reason)
		adm.deps.Exit.BatchDisableWithSource([]string{body.RawURI}, nodestore.DisableSourceUnsupported, unsupportedReason, unsupportedCls)
		writeJSON(w, http.StatusOK, map[string]any{
			"ok": false, "elapsed_ms": 0, "error": reason, "disabled": true,
		})
		return
	}

	start := time.Now()
	sess, err := adm.vc.Net().CreateSession(15, body.RawURI, "admin-test-node")
	var testErr error
	if err == nil {
		testErr = adm.fetchRecaptchaTokenWithSess(ctx, sess)
		sess.Close()
	} else {
		testErr = err
	}
	elapsed := float64(time.Since(start).Milliseconds())

	errStr := ""
	ok := testErr == nil
	if testErr != nil {
		if ctx.Err() != nil || errors.Is(testErr, context.DeadlineExceeded) {
			errStr = "timeout"
		} else {
			errStr = testErr.Error()
		}
	}

	disabled := false
	if body.AutoDisable {
		adm.deps.Exit.ReportProbe(body.RawURI, exitpool.ProbeResult{
			OK: ok, Ms: elapsed, ErrStr: errStr, Source: nodestore.ProbeSourceAdminSingle,
		})
		disabled = !ok
		if !ok {
			// 手动单测失败 → 直接禁用（评审确认的既有语义，不走阈值）：这是管理员主动
			// 点的一次测试，失败即摘除；来源记 admin_test，需人工启用恢复。
			cls, reason := adminDisableAudit("手动测试失败", errStr)
			adm.deps.Exit.BatchDisableWithSource([]string{body.RawURI}, nodestore.DisableSourceAdminTest, reason, cls)
		}
	}

	log.Printf("[Admin] [TestNode] 节点测试 %s: ok=%v elapsed=%.0fms error=%q disabled=%v", adm.deps.Exit.NodeName(body.RawURI), ok, elapsed, errStr, disabled)
	writeJSON(w, http.StatusOK, map[string]any{
		"ok":         ok,
		"elapsed_ms": elapsed,
		"error":      errStr,
		"disabled":   disabled,
	})
}

func (adm *AdminHandler) fetchRecaptchaTokenWithSess(ctx context.Context, sess *transport.Session) error {
	_, err := adm.deps.Tokens.FetchTokenWithSession(ctx, sess)
	return err
}

// adminProbeNode 手动探测一个（通常已被禁用的）节点。
//
// 与自动探测复用同一例程 probeNodeOnce：同样的超时、同样的健康判定与恢复路径，
// 成功即自动解除"健康触发"的禁用，失败则保持禁用并回传失败原因（不回写 admin_test
// 这类不可恢复来源、也不参与永久禁用升级——那是自动探测连续失败才有的语义）。
// 关闭自动探测不影响本接口：管理员始终能手动恢复禁用节点。
func (adm *AdminHandler) adminProbeNode(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		adm.adminMethodNotAllowed(w)
		return
	}
	var body struct {
		RawURI string `json:"raw_uri"`
	}
	if !adm.decodeAdminBody(w, r, &body) {
		return
	}
	uri := strings.TrimSpace(body.RawURI)
	if uri == "" {
		writeJSON(w, http.StatusBadRequest, adminErr("raw_uri 不能为空"))
		return
	}
	if adm.deps.Exit == nil || adm.deps.VC == nil || adm.deps.Tokens == nil || adm.deps.IR == nil {
		writeJSON(w, http.StatusServiceUnavailable, adminErr("探测依赖未就绪"))
		return
	}

	// 只允许探测"节点池内且已禁用"的节点：手动探测的语义是管理已禁用节点，
	// 不是提供任意目标 URI 的服务端出站探测入口。
	exists, disabled := adm.deps.Exit.NodeState(uri)
	if !exists {
		writeJSON(w, http.StatusNotFound, adminErr("节点不在节点池中"))
		return
	}
	if !disabled {
		writeJSON(w, http.StatusBadRequest, adminErr("该节点未处于禁用状态，无需探测"))
		return
	}

	ctx, cancel := context.WithTimeout(r.Context(), probeTimeoutSec*time.Second)
	defer cancel()

	out := probeNodeOnce(ctx, adm.deps, uri, nodestore.ProbeSourceAdminSingle, "admin-probe-node")
	if out.Busy {
		// 同节点重复触发保护：已有自动/手动探测在途，直接返回冲突而不重复探测。
		writeJSON(w, http.StatusConflict, map[string]any{
			"ok": false, "busy": true,
			"error": map[string]any{"message": "该节点正在探测中，请稍候"},
		})
		return
	}

	log.Printf("[Admin] [Probe] 节点 %s 手动探测: ok=%v elapsed=%.0fms recovered=%v disabled=%v error=%q",
		adm.deps.Exit.NodeName(uri), out.OK, out.Ms, out.Recovered, out.Disabled, out.Err)
	writeJSON(w, http.StatusOK, map[string]any{
		"ok":            out.OK,
		"elapsed_ms":    out.Ms,
		"error":         out.Err,
		"failure_class": string(out.Class),
		"recovered":     out.Recovered,
		"disabled":      out.Disabled,
		"probed_at":     time.Now().Unix(),
		"node":          adm.deps.Exit.NodeName(uri),
	})
}

// adminProbeDisabledNodes 批量手动探测禁用节点（【节点故障策略与记录】页入口）。
//
// health_only=true（默认）只探"健康禁用"节点——它们是唯一能被探测恢复的来源；
// false 则探全部禁用节点（人工/admin_test/permanent/unsupported 只做可达性检查与
// 故障记录，不会被放开）。与批量测速共用独占令牌与进度：同一时刻只允许一个批量任务，
// 并支持暂停/终止（复用既有 /nodes/test-pause|resume|terminate）。
func (adm *AdminHandler) adminProbeDisabledNodes(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		adm.adminMethodNotAllowed(w)
		return
	}
	var body struct {
		HealthOnly *bool `json:"health_only"`
	}
	if !adm.decodeAdminBody(w, r, &body) {
		return
	}
	healthOnly := true
	if body.HealthOnly != nil {
		healthOnly = *body.HealthOnly
	}
	if adm.deps.Exit == nil || adm.deps.VC == nil || adm.deps.Tokens == nil || adm.deps.IR == nil {
		writeJSON(w, http.StatusServiceUnavailable, adminErr("探测依赖未就绪"))
		return
	}

	targets := adm.disabledProbeTargets(healthOnly)
	if len(targets) == 0 {
		writeJSON(w, http.StatusOK, map[string]any{"ok": true, "total": 0, "health_only": healthOnly})
		return
	}
	if !adm.deps.Exit.StartTestProgress(len(targets)) {
		writeJSON(w, http.StatusConflict, adminErr("已有批量任务正在进行中，请先等待其结束或终止"))
		return
	}
	adm.deps.Exit.SetTestProgressKind("probe")

	concurrency := getBatchTestConcurrency()
	rounds := (len(targets) + concurrency - 1) / concurrency
	dynamicTimeout := time.Duration(rounds*2)*singleNodeTestTimeoutSec*time.Second + 2*time.Minute
	if dynamicTimeout < 5*time.Minute {
		dynamicTimeout = 5 * time.Minute
	}
	log.Printf("[Admin] [ProbeBatch] 开始批量探测 %d 个禁用节点（health_only=%v, 并发 %d, 超时 %v）",
		len(targets), healthOnly, concurrency, dynamicTimeout)

	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), dynamicTimeout)
		// 与批量测速共用终止入口：/nodes/test-terminate 取消当前批次。
		testAllMu.Lock()
		myGen := testAllGen + 1
		testAllGen = myGen
		if testAllCancel != nil {
			testAllCancel()
		}
		testAllCancel = cancel
		testAllMu.Unlock()
		defer func() {
			cancel()
			testAllMu.Lock()
			if testAllGen == myGen {
				testAllCancel = nil
			}
			testAllMu.Unlock()
		}()

		// 有限 worker 池：生产者逐个投递并在投递处检查暂停/终止，worker 调用 probeNodeOnce。
		runBatchTasks(ctx, targets, concurrency, adm.deps.Exit.CheckTestControl, func(uri string) {
			out := probeNodeOnce(ctx, adm.deps, uri, nodestore.ProbeSourceAdminBatch, "admin-probe-batch")
			adm.deps.Exit.UpdateTestProgress(adm.deps.Exit.NodeName(uri), out.OK)
		})
		adm.deps.Exit.FinishTestProgress()
		log.Printf("[Admin] [ProbeBatch] 批量探测结束（共 %d 个）", len(targets))
	}()

	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "total": len(targets), "health_only": healthOnly})
}

// disabledProbeTargets 枚举批量探测目标：health_only 只取可自动恢复的禁用节点，
// 否则取全部禁用节点。
func (adm *AdminHandler) disabledProbeTargets(healthOnly bool) []string {
	if !healthOnly {
		return adm.deps.Exit.DisabledURIs()
	}
	set := adm.deps.Exit.HealthAutoDisabledURIs()
	out := make([]string, 0, len(set))
	for uri := range set {
		out = append(out, uri)
	}
	return out
}

func (adm *AdminHandler) fetchSubscriptionText(ctx context.Context, rawURL string) (string, error) {
	rawURL = strings.TrimSpace(rawURL)
	if rawURL == "" {
		return "", errors.New("subscription url is empty")
	}

	if adm.vc != nil && adm.vc.Net() != nil {
		log.Printf("[Admin] [FetchSub] 经前置代理池拉取订阅")
		data, err := fetchSubscriptionDataViaProxy(ctx, adm.vc.Net(), rawURL)
		if err == nil {
			return strings.TrimSpace(string(data)), nil
		}
		log.Printf("[Admin] [FetchSub] 前置代理拉取失败 (%v)，回退直连", err)
	}

	data, err := fetchSubscriptionDataDirect(ctx, rawURL)
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(string(data)), nil
}

func fetchSubscriptionDataDirect(ctx context.Context, rawURL string) ([]byte, error) {
	client := netx.NewHTTPClient(30 * time.Second)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, rawURL, nil)
	if err != nil {
		return nil, fmt.Errorf("error: %w", err)
	}
	req.Header.Set("User-Agent", subscriptionFetchUserAgent)
	req.Header.Set("Accept", "*/*")

	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("error: %w", err)
	}
	if resp == nil {
		return nil, fmt.Errorf("nil response received")
	}
	defer func() { _ = resp.Body.Close() }()

	data, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("error: %w", err)
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("status code %d", resp.StatusCode)
	}
	return data, nil
}

func fetchSubscriptionDataViaProxy(ctx context.Context, netClient *transport.NetworkClient, rawURL string) ([]byte, error) {
	if netClient == nil {
		return nil, errors.New("network client unavailable")
	}

	sess, err := netClient.CreateSession(30, "", "admin-fetch-sub")
	if err != nil {
		return nil, fmt.Errorf("error: %w", err)
	}
	defer sess.Close()

	header := transport.Header{
		"user-agent": {subscriptionFetchUserAgent},
		"accept":     {"*/*"},
	}
	statusCode, data, err := sess.DoAndRead(ctx, http.MethodGet, rawURL, header, nil)
	if err != nil {
		return nil, fmt.Errorf("error: %w", err)
	}
	if statusCode != http.StatusOK {
		return nil, fmt.Errorf("status code %d", statusCode)
	}
	return data, nil
}
