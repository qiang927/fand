package api

import (
	"context"
	"sync"
	"testing"
	"time"
)

// TestRunBatchTasks_BoundedWorkers 校验有限 worker 池：并发不超过上限，且全部任务被执行。
func TestRunBatchTasks_BoundedWorkers(t *testing.T) {
	const (
		n     = 60
		limit = 4
	)
	targets := make([]int, n)
	for i := range targets {
		targets[i] = i
	}

	var mu sync.Mutex
	inFlight, maxInFlight, done := 0, 0, 0
	runBatchTasks(context.Background(), targets, limit, nil, func(int) {
		mu.Lock()
		inFlight++
		if inFlight > maxInFlight {
			maxInFlight = inFlight
		}
		mu.Unlock()

		time.Sleep(time.Millisecond)

		mu.Lock()
		inFlight--
		done++
		mu.Unlock()
	})

	if done != n {
		t.Fatalf("应执行全部任务, done=%d want %d", done, n)
	}
	if maxInFlight > limit {
		t.Fatalf("并发超过上限: max=%d limit=%d", maxInFlight, limit)
	}
}

// TestRunBatchTasks_StopAtDispatch shouldStop 在投递处生效：置位后不再派发新任务
// （暂停/终止可即时生效，而不是等每个任务自己拿到调度）。
func TestRunBatchTasks_StopAtDispatch(t *testing.T) {
	const n = 100
	targets := make([]int, n)
	for i := range targets {
		targets[i] = i
	}

	var mu sync.Mutex
	stop := false
	count := 0
	runBatchTasks(context.Background(), targets, 2, func() bool {
		mu.Lock()
		defer mu.Unlock()
		return stop
	}, func(int) {
		mu.Lock()
		count++
		if count == 3 {
			stop = true
		}
		mu.Unlock()
	})

	mu.Lock()
	got := count
	mu.Unlock()
	if got >= n {
		t.Fatalf("shouldStop 生效后不应派发全部任务, count=%d", got)
	}
	if got < 3 {
		t.Fatalf("停止前应至少执行 3 个任务, count=%d", got)
	}
}

// TestRunBatchTasks_ContextCancel 上下文取消时不再派发并正常收尾（不阻塞）。
func TestRunBatchTasks_ContextCancel(t *testing.T) {
	targets := make([]int, 100)
	ctx, cancel := context.WithCancel(context.Background())
	cancel()

	done := make(chan struct{})
	go func() {
		runBatchTasks(ctx, targets, 3, nil, func(int) { time.Sleep(time.Millisecond) })
		close(done)
	}()
	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("上下文已取消时 runBatchTasks 未及时返回")
	}
}
