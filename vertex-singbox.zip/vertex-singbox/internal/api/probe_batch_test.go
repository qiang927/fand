package api

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/bsfdsagfadg/vertex/internal/node/exitpool"
	"github.com/bsfdsagfadg/vertex/internal/node/nodestore"
)

// waitBatchDone 等待批量任务结束（最多 5s），避免测试间共享令牌泄漏。
func waitBatchDone(t *testing.T, mgr *exitpool.Manager) {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		if !mgr.IsTestRunning() {
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatal("批量任务未在预期时间内结束")
}

// seedDisabledNodes 造两个禁用节点：u1 健康禁用（可恢复）、u2 人工禁用。
func seedDisabledNodes(t *testing.T, mgr *exitpool.Manager) (healthURI, manualURI string) {
	t.Helper()
	healthURI, manualURI = "socks5://127.0.0.1:1", "socks5://127.0.0.1:2"
	mgr.MergeNodes([]exitpool.Node{ //nolint:exhaustruct
		{RawURI: healthURI, Type: "socks5", Name: "h"},
		{RawURI: manualURI, Type: "socks5", Name: "m"},
	})
	mgr.ReportProbe(healthURI, exitpool.ProbeResult{OK: false, ErrStr: "dial tcp: connection refused"})
	if !mgr.HealthAutoDisabledURIs()[healthURI] {
		t.Fatal("前置：u1 应为健康禁用")
	}
	mgr.BatchUpdateNodesDisabled([]string{manualURI}, true)
	return healthURI, manualURI
}

// TestAdminProbeDisabledNodes_DefaultHealthOnlyAndAll 默认（不带 health_only）只探健康禁用；
// health_only=false 探全部禁用节点。两个用例各用独立节点池——探测成功会恢复健康禁用节点，
// 复用同一池会让第二次调用看到的禁用集合已经变化。
func TestAdminProbeDisabledNodes_DefaultHealthOnlyAndAll(t *testing.T) {
	probe := func(t *testing.T, body string) map[string]any {
		t.Helper()
		mgr := newProbeTestManager()
		seedDisabledNodes(t, mgr)
		adm := newProbeTestHandler(t, nil, mgr, fakeTokenVerifier{}, &trackingDialer{})
		rec := httptest.NewRecorder()
		adm.adminProbeDisabledNodes(rec, probeReq(body))
		if rec.Code != http.StatusOK {
			t.Fatalf("code=%d, want 200 body=%s", rec.Code, rec.Body.String())
		}
		if got := mgr.GetTestProgress().Kind; got != "probe" {
			t.Errorf("进度 Kind=%q, want probe", got)
		}
		waitBatchDone(t, mgr)
		var out map[string]any
		if err := json.Unmarshal(rec.Body.Bytes(), &out); err != nil {
			t.Fatalf("解析响应失败: %v", err)
		}
		return out
	}

	if out := probe(t, `{}`); out["total"] != float64(1) || out["health_only"] != true {
		t.Fatalf("默认应只探 1 个健康禁用节点: %v", out)
	}
	if out := probe(t, `{"health_only":false}`); out["total"] != float64(2) {
		t.Fatalf("health_only=false 应探全部 2 个禁用节点: %v", out)
	}
}

// TestAdminProbeDisabledNodes_EmptyAndDepsMissing 无禁用节点返回 total=0；依赖缺失返回 503。
func TestAdminProbeDisabledNodes_EmptyAndDepsMissing(t *testing.T) {
	adm := newProbeTestHandler(t, nil, newProbeTestManager(), fakeTokenVerifier{}, &trackingDialer{})
	rec := httptest.NewRecorder()
	adm.adminProbeDisabledNodes(rec, probeReq(`{}`))
	if rec.Code != http.StatusOK || !strings.Contains(rec.Body.String(), `"total":0`) {
		t.Fatalf("无禁用节点应返回 total=0: code=%d body=%s", rec.Code, rec.Body.String())
	}

	// 依赖缺失（Exit 为 nil）→ 503。
	missing := &AdminHandler{handler: handler{deps: ServerDeps{}}}
	rec = httptest.NewRecorder()
	missing.adminProbeDisabledNodes(rec, probeReq(`{}`))
	if rec.Code != http.StatusServiceUnavailable {
		t.Fatalf("依赖缺失应返回 503, got %d", rec.Code)
	}
}

// TestAdminProbeDisabledNodes_Busy409 已有批量任务占用时返回 409。
func TestAdminProbeDisabledNodes_Busy409(t *testing.T) {
	mgr := newProbeTestManager()
	seedDisabledNodes(t, mgr)
	if !mgr.StartTestProgress(1) {
		t.Fatal("前置：应能占用批量令牌")
	}
	defer mgr.FinishTestProgress()

	adm := newProbeTestHandler(t, nil, mgr, fakeTokenVerifier{}, &trackingDialer{})
	rec := httptest.NewRecorder()
	adm.adminProbeDisabledNodes(rec, probeReq(`{"health_only":true}`))
	if rec.Code != http.StatusConflict {
		t.Fatalf("code=%d, want 409, body=%s", rec.Code, rec.Body.String())
	}
}

// TestAdminProbeDisabledNodes_RecoveryBoundary 锁定"来源驱动恢复"这条产品规则：
// 批量手动探测成功**只**能放开 health（可自动恢复）来源；admin_test / 人工 /
// permanent / unsupported 等来源即使探测成功也保持禁用（只能人工启用）。
func TestAdminProbeDisabledNodes_RecoveryBoundary(t *testing.T) {
	mgr := newProbeTestManager()
	const (
		uriHealth      = "socks5://127.0.0.1:1"
		uriManual      = "socks5://127.0.0.1:2"
		uriAdminTest   = "socks5://127.0.0.1:3"
		uriPermanent   = "socks5://127.0.0.1:4"
		uriUnsupported = "socks5://127.0.0.1:5"
	)
	mgr.MergeNodes([]exitpool.Node{ //nolint:exhaustruct
		{RawURI: uriHealth, Type: "socks5", Name: "h"},
		{RawURI: uriManual, Type: "socks5", Name: "m"},
		{RawURI: uriAdminTest, Type: "socks5", Name: "t"},
		{RawURI: uriPermanent, Type: "socks5", Name: "p"},
		{RawURI: uriUnsupported, Type: "socks5", Name: "u"},
	})

	// 五种禁用来源。
	mgr.ReportProbe(uriHealth, exitpool.ProbeResult{OK: false, ErrStr: "dial tcp: connection refused"})
	if !mgr.HealthAutoDisabledURIs()[uriHealth] {
		t.Fatal("前置：uriHealth 应为 health 禁用")
	}
	mgr.BatchUpdateNodesDisabled([]string{uriManual}, true)
	mgr.BatchDisableWithSource([]string{uriAdminTest}, nodestore.DisableSourceAdminTest, "测试失败", "node_network")
	mgr.BatchDisableWithSource([]string{uriPermanent}, nodestore.DisableSourcePermanent, "持续不可恢复", "node_network")
	mgr.BatchDisableWithSource([]string{uriUnsupported}, nodestore.DisableSourceUnsupported, "协议不支持", "unsupported")

	// 探测一律成功（trackingDialer + fakeTokenVerifier），探全部禁用节点。
	adm := newProbeTestHandler(t, nil, mgr, fakeTokenVerifier{}, &trackingDialer{})
	rec := httptest.NewRecorder()
	adm.adminProbeDisabledNodes(rec, probeReq(`{"health_only":false}`))
	if rec.Code != http.StatusOK {
		t.Fatalf("code=%d, want 200 body=%s", rec.Code, rec.Body.String())
	}
	waitBatchDone(t, mgr)

	disabled := map[string]bool{}
	for _, n := range mgr.LoadNodes() {
		disabled[n.RawURI] = n.Disabled
	}
	if disabled[uriHealth] {
		t.Error("health 禁用节点探测成功应恢复")
	}
	for _, u := range []string{uriManual, uriAdminTest, uriPermanent, uriUnsupported} {
		if !disabled[u] {
			t.Errorf("来源不可自动恢复的节点（%s）探测成功也不得被放开", u)
		}
	}
}
