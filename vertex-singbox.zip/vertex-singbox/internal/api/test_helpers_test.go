package api

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/bsfdsagfadg/vertex/internal/engine/recaptcha"
	"github.com/bsfdsagfadg/vertex/internal/engine/vertex"
	"github.com/bsfdsagfadg/vertex/internal/infra/config"
	"github.com/bsfdsagfadg/vertex/internal/infra/db"
	"github.com/bsfdsagfadg/vertex/internal/infra/transport"
	"github.com/bsfdsagfadg/vertex/internal/node/entrypool"
	"github.com/bsfdsagfadg/vertex/internal/node/exitpool"
	"github.com/bsfdsagfadg/vertex/internal/node/importer"
)

// testFixture 封装集成测试用到的依赖。
type testFixture struct {
	server       *httptest.Server
	mockUpstream *httptest.Server
	keys         *APIKeyManager
	vc           *vertex.VertexAIClient
	// exitMgr 暴露出口节点池，供"请求级拒绝不得触碰节点健康"类断言使用。
	exitMgr *exitpool.Manager
}

// assembleDomainManagers 构造测试专用的领域成品实例（与 main.go 装配链同构，
// 但使用独立 IRCache 与传入 DB，实现用例间完全隔离）。
func assembleDomainManagers(database *sql.DB) (*exitpool.Manager, *entrypool.EntryManager, *transport.IRCache) {
	irCache := transport.NewIRCache()
	resolver := transport.NewIdentityResolver(irCache)
	exitMgr := exitpool.NewManager(database, resolver, exitpool.Hooks{
		InvalidateParsed: irCache.InvalidateBatch,
		InvalidateAll:    irCache.Clear,
	}, nil)
	entryMgr := entrypool.NewEntryManager(database, resolver, entrypool.EntryHooks{
		InvalidateParsed: irCache.InvalidateOne,
	}, nil)
	return exitMgr, entryMgr, irCache
}

// newTestServer 创建完整的测试服务器。
//
// 设置临时 config.json、api_keys.txt、内存 DB、mock 上游（batchGraphql 端点），
// 覆盖 batchGraphqlURL 到 mock 服务，注入 mock recaptcha token pool。
//
// 使用 t.Cleanup 自动清理，因此返回的 fixture 在子测试结束后仍有效（server 在
// 用例结束后关闭）。
func newTestServer(t *testing.T) *testFixture {
	t.Helper()

	dir := t.TempDir()

	// ── config.json ──
	cfg := config.DefaultConfig()
	cfg.AdminPassword = "test-admin-pw"
	cfg.ParallelPoolEnabled = false
	cfg.ActiveNodeURI = ""
	cfg.MaxRetries = 0
	cfgBytes, err := json.MarshalIndent(cfg, "", "  ")
	if err != nil {
		t.Fatalf("marshal config: %v", err)
	}
	if err := os.WriteFile(filepath.Join(dir, "config.json"), cfgBytes, 0o644); err != nil {
		t.Fatalf("write config: %v", err)
	}
	t.Setenv("VPROXY_CONFIG", filepath.Join(dir, "config.json"))
	config.InvalidateCache()

	// ── api_keys.txt ──
	keysContent := "test:sk-test-key:Test Key\n"
	if err := os.WriteFile(filepath.Join(dir, "api_keys.txt"), []byte(keysContent), 0o644); err != nil {
		t.Fatalf("write api_keys: %v", err)
	}
	t.Setenv("VPROXY_API_KEYS", filepath.Join(dir, "api_keys.txt"))

	// ── DB ──
	database, err := db.Open(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatalf("open db: %v", err)
	}
	exitMgr, entryMgr, irCache := assembleDomainManagers(database)

	// ── mock upstream（batchGraphql）──
	mockUpstream := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = io.ReadAll(r.Body)

		w.Header().Set("Content-Type", "application/json; charset=utf-8")
		w.WriteHeader(http.StatusOK)

		// 返回一个标准 Gemini 响应（非流式非数组包装）
		resp := fmt.Sprintf(`[{"results":[{"data":{"ui":{"streamGenerateContentAnonymous":%s}}}]}]`,
			geminiNonStreamingResponse())
		_, _ = w.Write([]byte(resp))
	}))

	// ── token pool（mock）──
	mockPool := recaptcha.NewTokenPoolCustom(func(proxyURI string) (string, error) {
		return "test-recaptcha-token", nil
	})

	// ── VertexAIClient ──
	netClient := transport.NewNetworkClient(nil)
	vc := vertex.NewVertexAIClient(config.StaticProvider(cfg), netClient, nil, nil)
	vc.SetTokenPool(mockPool)
	vc.SetBatchGraphqlURL(mockUpstream.URL + "/batchGraphql?key=test&prettyPrint=false")

	// ── 恢复 api 全局状态 ──
	resetAdminSessions()
	// 重新加载，确保 test 内路径
	keys := NewAPIKeyManager()
	keys.LoadKeys()

	// ── HTTP server ──
	srv := NewServer(ServerDeps{
		VC:      vc,
		Keys:    keys,
		Cfg:     config.StaticProvider(cfg),
		Exit:    exitMgr,
		Entry:   entryMgr,
		Imports: importer.NewService(),
		Tokens:  mockPool,
		IR:      irCache,
		DB:      db.NewDBMaintenance(database, filepath.Join(dir, "test.db")),
	})
	ts := httptest.NewServer(srv.Handler())

	t.Cleanup(func() {
		ts.Close()
		mockUpstream.Close()
		_ = database.Close()
		config.InvalidateCache()
	})

	return &testFixture{
		server:       ts,
		mockUpstream: mockUpstream,
		keys:         keys,
		vc:           vc,
		exitMgr:      exitMgr,
	}
}

// newTestServerCustomMock 创建带自定义 mock upstream handler 的测试服务器。
// 同时允许调用方修改 config 后再创建 VertexAIClient。
// dialers 为可选的 dialer 参数，用于并行池测试。
func newTestServerCustomMock(t *testing.T, mockHandler http.HandlerFunc, cfgMod func(*config.AppConfig), dialers ...transport.ProxyDialer) *testFixture {
	t.Helper()

	dir := t.TempDir()

	// ── 基础 config ──
	cfg := config.DefaultConfig()
	cfg.AdminPassword = "test-admin-pw"
	cfg.ParallelPoolEnabled = false
	cfg.ActiveNodeURI = ""
	cfg.MaxRetries = 0
	cfg.RequestTimeoutSeconds = 180
	if cfgMod != nil {
		cfgMod(&cfg)
	}
	cfgBytes, err := json.MarshalIndent(cfg, "", "  ")
	if err != nil {
		t.Fatalf("marshal config: %v", err)
	}
	if err := os.WriteFile(filepath.Join(dir, "config.json"), cfgBytes, 0o644); err != nil {
		t.Fatalf("write config: %v", err)
	}
	t.Setenv("VPROXY_CONFIG", filepath.Join(dir, "config.json"))
	config.InvalidateCache()

	// ── api_keys.txt ──
	keysContent := "test:sk-test-key:Test Key\n"
	if err := os.WriteFile(filepath.Join(dir, "api_keys.txt"), []byte(keysContent), 0o644); err != nil {
		t.Fatalf("write api_keys: %v", err)
	}
	t.Setenv("VPROXY_API_KEYS", filepath.Join(dir, "api_keys.txt"))

	// ── DB ──
	database, err := db.Open(filepath.Join(dir, "test.db"))
	if err != nil {
		t.Fatalf("open db: %v", err)
	}
	exitMgr, entryMgr, irCache := assembleDomainManagers(database)

	// ── mock upstream 使用可取消 BaseContext ──
	// 当 handler 阻塞（如 upstream_hang 测试）时，cleanup 先取消 baseCtx，
	// 使所有活跃 handler 的 r.Context().Done() 立即触发，避免 httptest.Server.Close()
	// 因等待 handler 返回而长时间挂起。
	mockUpstreamCtx, mockUpstreamCancel := context.WithCancel(context.Background())
	mockUpstream := httptest.NewUnstartedServer(http.HandlerFunc(mockHandler))
	mockUpstream.Config.BaseContext = func(net.Listener) context.Context {
		return mockUpstreamCtx
	}
	mockUpstream.Start()

	// ── token pool ──
	mockPool := recaptcha.NewTokenPoolCustom(func(proxyURI string) (string, error) {
		return "test-recaptcha-token", nil
	})

	// ── VertexAIClient ──
	var dialer transport.ProxyDialer
	if len(dialers) > 0 {
		dialer = dialers[0]
	}
	netClient := transport.NewNetworkClient(dialer)
	vc := vertex.NewVertexAIClient(config.StaticProvider(cfg), netClient, nil, nil)
	vc.SetTokenPool(mockPool)
	vc.SetBatchGraphqlURL(mockUpstream.URL + "/batchGraphql?key=test&prettyPrint=false")

	// ── 恢复全局状态 ──
	resetAdminSessions()
	keys := NewAPIKeyManager()
	keys.LoadKeys()

	// ── HTTP server ──
	srv := NewServer(ServerDeps{
		VC:      vc,
		Keys:    keys,
		Cfg:     config.StaticProvider(cfg),
		Exit:    exitMgr,
		Entry:   entryMgr,
		Dialer:  dialer,
		Imports: importer.NewService(),
		Tokens:  mockPool,
		IR:      irCache,
		DB:      db.NewDBMaintenance(database, filepath.Join(dir, "test.db")),
	})
	ts := httptest.NewServer(srv.Handler())

	t.Cleanup(func() {
		ts.Close()
		mockUpstreamCancel()
		mockUpstream.Close()
		_ = database.Close()
		config.InvalidateCache()
	})

	return &testFixture{
		server:       ts,
		mockUpstream: mockUpstream,
		keys:         keys,
		vc:           vc,
		exitMgr:      exitMgr,
	}
}

// doPost 发送 POST 请求，body 自动 JSON 序列化。apiKey 为空时省略 Authorization 头。
func doPost(t *testing.T, url, apiKey string, body any) *http.Response {
	t.Helper()
	var buf io.Reader
	if body != nil {
		b, err := json.Marshal(body)
		if err != nil {
			t.Fatalf("marshal: %v", err)
		}
		buf = strings.NewReader(string(b))
	}
	req, err := http.NewRequest(http.MethodPost, url, buf)
	if err != nil {
		t.Fatalf("new request: %v", err)
	}
	if apiKey != "" {
		req.Header.Set("Authorization", "Bearer "+apiKey)
	}
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("do request: %v", err)
	}
	return resp
}

// geminiNonStreamingResponse 返回标准 Gemini 非流式响应的 JSON（data.ui.streamGenerateContentAnonymous 值部分）。
func geminiNonStreamingResponse() string {
	return `{"candidates":[{"content":{"parts":[{"text":"Hello! How can I help you today?"}],"role":"model"},"finishReason":"STOP"}],"usageMetadata":{"promptTokenCount":10,"candidatesTokenCount":20,"totalTokenCount":30}}`
}
