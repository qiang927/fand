package api

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/bsfdsagfadg/vertex/internal/engine/vertex"
	"github.com/bsfdsagfadg/vertex/internal/infra/config"
	"github.com/bsfdsagfadg/vertex/internal/infra/transport"
	"github.com/bsfdsagfadg/vertex/internal/node/exitpool"
	"github.com/bsfdsagfadg/vertex/internal/node/nodestore"
)

// fakeTokenVerifier 实现 TokenVerifier，用于探测路径的单测（不发起真实抓取）。
type fakeTokenVerifier struct{ err error }

func (f fakeTokenVerifier) FetchTokenWithSession(_ context.Context, _ *transport.Session) (string, error) {
	return "fake-token", f.err
}

func newProbeTestManager() *exitpool.Manager {
	return exitpool.NewManager(nil, nil, exitpool.Hooks{}, func() int { return 2 })
}

func newProbeTestHandler(t *testing.T, cfg *config.AppConfig, mgr *exitpool.Manager, tokens TokenVerifier, dialer transport.ProxyDialer) *AdminHandler {
	t.Helper()
	var provider config.ConfigProvider
	if cfg != nil {
		provider = config.StaticProvider(*cfg)
	}
	vc := vertex.NewVertexAIClient(provider, transport.NewNetworkClient(dialer), nil, nil)
	return &AdminHandler{handler: handler{deps: ServerDeps{
		Cfg: provider, Exit: mgr, VC: vc, Tokens: tokens, IR: transport.NewIRCache(),
	}}}
}

func probeReq(body string) *http.Request {
	return httptest.NewRequest(http.MethodPost, "/api/admin/nodes/probe", strings.NewReader(body))
}

// TestProbeNodeOnce_Busy 同节点已有探测在途时 probeNodeOnce 直接返回 Busy，
// 不触碰任何网络依赖（deps.VC 为 nil 也不得 panic）。
func TestProbeNodeOnce_Busy(t *testing.T) {
	mgr := newProbeTestManager()
	deps := ServerDeps{Exit: mgr, IR: transport.NewIRCache()}
	if !mgr.TryBeginProbe("u1") {
		t.Fatal("前置：应能占住探测权")
	}
	out := probeNodeOnce(context.Background(), deps, "u1", nodestore.ProbeSourceAdminSingle, "test")
	if !out.Busy {
		t.Fatal("在途探测应返回 Busy")
	}
	if out.OK {
		t.Fatal("Busy 不应被当作成功")
	}
}

// TestProbeNodeOnce_Unsupported 协议不支持/解析失败的节点：探测判失败、归因 unsupported、
// 返回可读原因（无需网络，deps.VC 为 nil）。
func TestProbeNodeOnce_Unsupported(t *testing.T) {
	mgr := newProbeTestManager()
	deps := ServerDeps{Exit: mgr, IR: transport.NewIRCache()}
	uri := "vless://uuid@example.com:443?type=xhttp"
	adm := &AdminHandler{handler: handler{deps: deps}}
	if supported, _, _ := adm.checkNodeSupport(uri); supported {
		t.Skipf("该节点在本版本被视为受支持，跳过: %s", uri)
	}
	mgr.MergeNodes([]exitpool.Node{{RawURI: uri, Type: "vless", Name: "n"}}) //nolint:exhaustruct

	out := probeNodeOnce(context.Background(), deps, uri, nodestore.ProbeSourceAdminSingle, "test")
	if out.OK {
		t.Fatal("不支持节点探测应为失败")
	}
	if out.Class != nodestore.FailureUnsupported {
		t.Errorf("归因类别=%q, want unsupported", out.Class)
	}
	if out.Err == "" {
		t.Error("应返回失败原因")
	}
}

// TestAdminProbeNode_EmptyURI 空 raw_uri 返回 400。
func TestAdminProbeNode_EmptyURI(t *testing.T) {
	adm := newProbeTestHandler(t, nil, newProbeTestManager(), fakeTokenVerifier{}, nil)
	rec := httptest.NewRecorder()
	adm.adminProbeNode(rec, probeReq(`{"raw_uri":"   "}`))
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("code=%d, want 400", rec.Code)
	}
}

// TestAdminProbeNode_DepsMissing 依赖未就绪返回 503（而非静默探测失败）。
func TestAdminProbeNode_DepsMissing(t *testing.T) {
	adm := &AdminHandler{handler: handler{deps: ServerDeps{}}}
	rec := httptest.NewRecorder()
	adm.adminProbeNode(rec, probeReq(`{"raw_uri":"u1"}`))
	if rec.Code != http.StatusServiceUnavailable {
		t.Fatalf("code=%d, want 503", rec.Code)
	}
}

// TestAdminProbeNode_Busy 同一节点已在探测中返回 409（重复触发保护）。
func TestAdminProbeNode_Busy(t *testing.T) {
	mgr := newProbeTestManager()
	const uri = "socks5://127.0.0.1:1"
	mgr.MergeNodes([]exitpool.Node{{RawURI: uri, Type: "socks5", Name: "n"}}) //nolint:exhaustruct
	mgr.ReportProbe(uri, exitpool.ProbeResult{OK: false, ErrStr: "dial tcp: connection refused"})
	if !mgr.TryBeginProbe(uri) {
		t.Fatal("前置：应能占住探测权")
	}
	defer mgr.EndProbe(uri)

	adm := newProbeTestHandler(t, nil, mgr, fakeTokenVerifier{}, nil)
	rec := httptest.NewRecorder()
	adm.adminProbeNode(rec, probeReq(`{"raw_uri":"`+uri+`"}`))
	if rec.Code != http.StatusConflict {
		t.Fatalf("code=%d, want 409", rec.Code)
	}
	var body map[string]any
	if err := json.Unmarshal(rec.Body.Bytes(), &body); err != nil {
		t.Fatalf("解析响应失败: %v", err)
	}
	if body["busy"] != true {
		t.Errorf("响应应带 busy=true, got %v", body["busy"])
	}
}

// TestAdminProbeNode_UnknownNode404 不在节点池中的 URI 返回 404：
// 手动探测只管理池内节点，不提供任意目标的出站探测入口。
func TestAdminProbeNode_UnknownNode404(t *testing.T) {
	adm := newProbeTestHandler(t, nil, newProbeTestManager(), fakeTokenVerifier{}, &trackingDialer{})
	rec := httptest.NewRecorder()
	adm.adminProbeNode(rec, probeReq(`{"raw_uri":"socks5://127.0.0.1:1080"}`))
	if rec.Code != http.StatusNotFound {
		t.Fatalf("code=%d, want 404, body=%s", rec.Code, rec.Body.String())
	}
}

// TestAdminProbeNode_EnabledNode400 池内但未禁用的节点返回 400：只探测已禁用节点。
func TestAdminProbeNode_EnabledNode400(t *testing.T) {
	mgr := newProbeTestManager()
	const uri = "socks5://127.0.0.1:1"
	mgr.MergeNodes([]exitpool.Node{{RawURI: uri, Type: "socks5", Name: "n"}}) //nolint:exhaustruct

	adm := newProbeTestHandler(t, nil, mgr, fakeTokenVerifier{}, &trackingDialer{})
	rec := httptest.NewRecorder()
	adm.adminProbeNode(rec, probeReq(`{"raw_uri":"`+uri+`"}`))
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("code=%d, want 400, body=%s", rec.Code, rec.Body.String())
	}
}

// TestAdminProbeNode_IndependentOfAutoProbeToggle 关闭自动探测不影响手动探测：
// 管理员仍可对禁用节点发起探测，探测成功即恢复（手动探测不读取 health_selfheal_enabled）。
func TestAdminProbeNode_IndependentOfAutoProbeToggle(t *testing.T) {
	cfg := config.DefaultConfig()
	cfg.HealthSelfHealEnabled = false // 关闭自动探测

	mgr := newProbeTestManager()
	const uri = "socks5://127.0.0.1:1"
	mgr.MergeNodes([]exitpool.Node{{RawURI: uri, Type: "socks5", Name: "n"}}) //nolint:exhaustruct
	// 先让节点进入 health 禁用（可被探测恢复的来源）。
	mgr.ReportProbe(uri, exitpool.ProbeResult{OK: false, ErrStr: "dial tcp: connection refused"})
	if !mgr.HealthAutoDisabledURIs()[uri] {
		t.Fatal("前置：节点应处于 health 禁用")
	}

	// trackingDialer 让 CreateSession 成功，fakeTokenVerifier 让 rT 抓取成功 → 探测成功。
	adm := newProbeTestHandler(t, &cfg, mgr, fakeTokenVerifier{}, &trackingDialer{})
	rec := httptest.NewRecorder()
	adm.adminProbeNode(rec, probeReq(`{"raw_uri":"`+uri+`"}`))

	if rec.Code != http.StatusOK {
		t.Fatalf("手动探测应始终可用（不受自动探测开关影响）, code=%d body=%s", rec.Code, rec.Body.String())
	}
	var body map[string]any
	if err := json.Unmarshal(rec.Body.Bytes(), &body); err != nil {
		t.Fatalf("解析响应失败: %v", err)
	}
	for _, k := range []string{"ok", "elapsed_ms", "probed_at"} {
		if _, present := body[k]; !present {
			t.Errorf("响应缺少字段 %q: %s", k, rec.Body.String())
		}
	}
	if body["ok"] != true || body["recovered"] != true {
		t.Errorf("探测成功应恢复节点: %s", rec.Body.String())
	}
	if mgr.LoadNodes()[0].Disabled {
		t.Error("探测成功后节点应恢复可用（自动探测已关闭也不受影响）")
	}
}

// ctxErrTokenVerifier 阻塞至 ctx 结束再返回其错误，用于验证探测取消/超时。
type ctxErrTokenVerifier struct{}

func (ctxErrTokenVerifier) FetchTokenWithSession(ctx context.Context, _ *transport.Session) (string, error) {
	<-ctx.Done()
	return "", ctx.Err()
}

// TestProbeNodeOnce_ContextCanceledKeepsDisabled 探测被取消（超时/取消）时判失败、
// 保持禁用、不 panic，并返回失败原因。
func TestProbeNodeOnce_ContextCanceledKeepsDisabled(t *testing.T) {
	mgr := newProbeTestManager()
	const uri = "socks5://127.0.0.1:1"
	mgr.MergeNodes([]exitpool.Node{{RawURI: uri, Type: "socks5", Name: "n"}}) //nolint:exhaustruct
	mgr.ReportProbe(uri, exitpool.ProbeResult{OK: false, ErrStr: "dial tcp: connection refused"})
	if !mgr.HealthAutoDisabledURIs()[uri] {
		t.Fatal("前置：节点应处于 health 禁用")
	}

	vc := vertex.NewVertexAIClient(config.StaticProvider(config.DefaultConfig()), transport.NewNetworkClient(&trackingDialer{}), nil, nil)
	deps := ServerDeps{Exit: mgr, VC: vc, Tokens: ctxErrTokenVerifier{}, IR: transport.NewIRCache()}

	ctx, cancel := context.WithCancel(context.Background())
	cancel() // 立即取消，模拟超时/中断
	out := probeNodeOnce(ctx, deps, uri, nodestore.ProbeSourceAdminSingle, "test")

	if out.OK {
		t.Fatal("被取消的探测应判失败")
	}
	if !out.Disabled {
		t.Fatal("取消后节点应保持禁用")
	}
	if out.Err == "" {
		t.Error("应返回失败原因")
	}
}
