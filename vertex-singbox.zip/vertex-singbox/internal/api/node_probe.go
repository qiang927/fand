package api

import (
	"context"
	"log"
	"time"

	"github.com/bsfdsagfadg/vertex/internal/node/exitpool"
	"github.com/bsfdsagfadg/vertex/internal/node/importer"
	"github.com/bsfdsagfadg/vertex/internal/node/nodestore"
)

// probeTimeoutSec 是单节点探测的统一超时（秒）：自动探测与手动探测共用，
// 保证两者"探测成功/失败"的判定口径完全一致，不维护两套行为。
const probeTimeoutSec = 15

// ProbeOutcome 是一次节点探测的结构化结果（自动/手动共用同一例程）。
type ProbeOutcome struct { //nolint:govet // 字段按语义分组可读性优先，见 store_mem.go NodeHealth 同例
	OK        bool                   // 探测是否成功（rT token 抓取成功）
	Ms        float64                // 探测耗时（毫秒）
	Err       string                 // 失败原因（已脱敏）；成功时为空
	Class     nodestore.FailureClass // 失败归因类别
	Recovered bool                   // 本次探测使节点从禁用恢复为可用
	Promoted  bool                   // 本次探测因连续失败把节点升级为永久禁用
	Busy      bool                   // 同一节点已有探测在途，本次跳过
	Disabled  bool                   // 探测结束后节点是否仍处于禁用
}

// probeNodeOnce 是自动探测与手动探测共用的单节点探测例程：
// capability 早检查 → CreateSession + rT token 抓取 → 经 ReportProbe 走既有健康判定与恢复路径。
//
// source 决定故障记录的发现渠道（nodestore.ProbeSourceAutoProbe / ProbeSourceAdminSingle），
// sessionTag 仅用于日志区分。同一节点重复触发由 exitpool.TryBeginProbe 保护：自动与手动
// 探测共享同一把 per-node 锁，避免同一节点被并发重复探测。
func probeNodeOnce(ctx context.Context, deps ServerDeps, uri, source, sessionTag string) ProbeOutcome {
	var out ProbeOutcome

	if !deps.Exit.TryBeginProbe(uri) {
		out.Busy = true
		out.Disabled = deps.Exit.DisableSourceOf(uri) != ""
		return out
	}
	defer deps.Exit.EndProbe(uri)

	// capability 早检查（对齐 test-all）：协议不支持/解析失败的节点保持禁用并记录真实原因。
	// 这类失败不参与"永久禁用"升级——问题在解析器不在节点，判它不可恢复没有依据。
	if pn, perr := deps.IR.GetOrParse(uri); perr != nil || pn == nil || !pn.Supported {
		reason := "parse failed"
		if perr != nil {
			reason = "parse failed: " + perr.Error()
		} else if pn != nil {
			reason = "unsupported: " + pn.UnsupportedReason
		}
		masked := nodestore.MaskSecrets(reason)
		deps.Exit.ReportProbe(uri, exitpool.ProbeResult{
			OK: false, ErrStr: masked,
			Class: nodestore.FailureUnsupported, Source: nodestore.ProbeSourceUnsupported,
		})
		out.Err = masked
		out.Class = nodestore.FailureUnsupported
		out.Disabled = deps.Exit.DisableSourceOf(uri) != ""
		return out
	}

	start := time.Now()
	sess, err := deps.VC.Net().CreateSession(probeTimeoutSec, uri, sessionTag)
	var testErr error
	if err == nil {
		_, testErr = deps.Tokens.FetchTokenWithSession(ctx, sess)
		sess.Close()
	} else {
		testErr = err
	}
	out.Ms = float64(time.Since(start).Milliseconds())
	out.OK = testErr == nil
	if testErr != nil {
		// 错误文本常带完整 URL（query 可能含凭据），下发管理面板前统一脱敏。
		out.Err = nodestore.MaskSecrets(importer.ErrToStr(testErr))
		out.Class = nodestore.ClassifyFailure(out.Err).Class
	}

	before := deps.Exit.DisableSourceOf(uri)
	deps.Exit.ReportProbe(uri, exitpool.ProbeResult{
		OK: out.OK, Ms: out.Ms, ErrStr: out.Err, Source: source,
	})
	after := deps.Exit.DisableSourceOf(uri)

	out.Recovered = out.OK && before != "" && after == ""
	out.Promoted = before == nodestore.DisableSourceHealth && after == nodestore.DisableSourcePermanent
	out.Disabled = after != ""
	return out
}

// logProbeOutcome 记录一次自动探测的结果日志（仅自动探测路径使用；手动探测由 handler 返回给面板）。
func logProbeOutcome(uri string, out ProbeOutcome) {
	switch {
	case out.Recovered:
		log.Printf("[Health] [AutoProbe] 节点 %s 探测成功（%.0fms），已自动解除禁用", uri, out.Ms)
	case out.Promoted:
		log.Printf("[Health] [AutoProbe] 节点 %s 探测连续失败达阈值，已转永久禁用", uri)
	}
}
