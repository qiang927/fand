package transform

import "fmt"

// AdapterRejectedError 表示「协议适配层拒绝」：请求在 OpenAI→Gemini 转换阶段就确定无法映射
// （远程/文件 URL、未知 content part、未知 tool 类型、空 image_url 等）。
//
// 它是**请求级**错误，与上游失败严格分离：不会发起任何真实上游请求，也绝不计入节点失败/
// 健康度，更不触发自动探测或禁用。
//
// transform 不能依赖 vertex（vertex 依赖 transform，会成环），故此处只携带 Message/Param；
// 由 api 层转换为 vertex.NewAdapterRejectedError 后按 OpenAI error schema 输出。
type AdapterRejectedError struct {
	Message string
	// Param 指向出错字段，便于 OpenAI 客户端定位，如 messages[0].content[1].image_url.url。
	Param string
}

func (e *AdapterRejectedError) Error() string { return e.Message }

// adapterRejected 构造一个适配层拒绝错误。
func adapterRejected(param, format string, args ...any) error {
	return &AdapterRejectedError{Message: fmt.Sprintf(format, args...), Param: param}
}

// contentPartParam 生成 content part 字段的定位路径。
func contentPartParam(msgIdx, partIdx int) string {
	return fmt.Sprintf("messages[%d].content[%d]", msgIdx, partIdx)
}
