package transform

import (
	"errors"
	"strings"
	"testing"
)

// ---- Issue #14：适配层拒绝（不支持的输入必须显式 400，不得静默丢弃）----

func mustAdapterRejected(t *testing.T, err error) *AdapterRejectedError {
	t.Helper()
	var are *AdapterRejectedError
	if !errors.As(err, &are) {
		t.Fatalf("应为 *AdapterRejectedError，实得 %T: %v", err, err)
	}
	return are
}

func chatWithParts(parts ...map[string]any) *OpenAIChatRequest {
	content := make([]any, 0, len(parts))
	for _, p := range parts {
		content = append(content, p)
	}
	return &OpenAIChatRequest{
		Model:    "gemini-2.5-flash",
		Messages: []OpenAIMessage{{Role: "user", Content: content}},
	}
}

// TestContentParts_RemoteURLRejected 远程/文件 URL 一律拒绝（不下载、不代理、不转 fileData）。
func TestContentParts_RemoteURLRejected(t *testing.T) {
	for _, url := range []string{
		"https://example.com/a.png",
		"http://example.com/a.png",
		"file:///tmp/a.png",
		"ftp://example.com/a.png",
	} {
		t.Run(url, func(t *testing.T) {
			_, _, err := OpenAIChatToGemini(chatWithParts(
				map[string]any{"type": "image_url", "image_url": map[string]any{"url": url}},
			), "gemini-2.5-flash", nil)
			are := mustAdapterRejected(t, err)
			if are.Param != "messages[0].content[0].image_url.url" {
				t.Errorf("param=%q，应指向出错字段", are.Param)
			}
			if !strings.Contains(are.Message, "unsupported image URL") {
				t.Errorf("message=%q", are.Message)
			}
		})
	}
}

// TestContentParts_EmptyImageURLRejected 空 image_url.url 也拒绝（此前静默丢弃）。
func TestContentParts_EmptyImageURLRejected(t *testing.T) {
	_, _, err := OpenAIChatToGemini(chatWithParts(
		map[string]any{"type": "image_url", "image_url": map[string]any{"url": ""}},
	), "gemini-2.5-flash", nil)
	are := mustAdapterRejected(t, err)
	if are.Param != "messages[0].content[0].image_url.url" {
		t.Errorf("param=%q", are.Param)
	}
}

// TestContentParts_MalformedDataURIRejected 畸形 data URI 拒绝且带 param。
func TestContentParts_MalformedDataURIRejected(t *testing.T) {
	for _, raw := range []string{
		"data:image/png;base64,!!!notbase64!!!", // 非法 base64
		"data:image/png;base64",                 // 缺逗号
		"data:image/png;base64,",                // 空载荷
	} {
		t.Run(raw, func(t *testing.T) {
			_, _, err := OpenAIChatToGemini(chatWithParts(
				map[string]any{"type": "image_url", "image_url": map[string]any{"url": raw}},
			), "gemini-2.5-flash", nil)
			are := mustAdapterRejected(t, err)
			if are.Param != "messages[0].content[0].image_url.url" {
				t.Errorf("param=%q", are.Param)
			}
		})
	}
}

// TestContentParts_DataURIAccepted data: URI 继续转换为 inlineData。
func TestContentParts_DataURIAccepted(t *testing.T) {
	req, _, err := OpenAIChatToGemini(chatWithParts(
		map[string]any{"type": "image_url", "image_url": map[string]any{"url": "data:image/png;base64,aGVsbG8="}},
	), "gemini-2.5-flash", nil)
	if err != nil {
		t.Fatalf("data URI 应被接受: %v", err)
	}
	parts := req.Contents[0].Parts
	if len(parts) != 1 || parts[0].InlineData == nil || parts[0].InlineData.MimeType != "image/png" {
		t.Fatalf("应转为 inlineData: %+v", parts)
	}
}

// TestContentParts_UnknownTypeRejected 未知/不支持的 content 类型必须拒绝。
func TestContentParts_UnknownTypeRejected(t *testing.T) {
	for _, typ := range []string{"file", "refusal", "input_video", ""} {
		t.Run(typ, func(t *testing.T) {
			_, _, err := OpenAIChatToGemini(chatWithParts(
				map[string]any{"type": typ},
			), "gemini-2.5-flash", nil)
			are := mustAdapterRejected(t, err)
			if are.Param != "messages[0].content[0].type" {
				t.Errorf("param=%q", are.Param)
			}
			if !strings.Contains(are.Message, "unsupported content type") {
				t.Errorf("message=%q", are.Message)
			}
		})
	}
}

// TestContentParts_TextPlusUnsupportedRejected 混排时必须整体拒绝——
// 绝不能只把 text 发给 Gemini 而静默丢掉不支持的部分。
func TestContentParts_TextPlusUnsupportedRejected(t *testing.T) {
	_, _, err := OpenAIChatToGemini(chatWithParts(
		map[string]any{"type": "text", "text": "hi"},
		map[string]any{"type": "file", "file": map[string]any{"file_id": "f1"}},
	), "gemini-2.5-flash", nil)
	are := mustAdapterRejected(t, err)
	if are.Param != "messages[0].content[1].type" {
		t.Errorf("param=%q，应指向第 2 个 part", are.Param)
	}
}

// TestContentParts_NonObjectPartRejected 数组元素不是对象时拒绝（不再静默跳过）。
func TestContentParts_NonObjectPartRejected(t *testing.T) {
	req := &OpenAIChatRequest{
		Model:    "gemini-2.5-flash",
		Messages: []OpenAIMessage{{Role: "user", Content: []any{"just-a-string"}}},
	}
	_, _, err := OpenAIChatToGemini(req, "gemini-2.5-flash", nil)
	are := mustAdapterRejected(t, err)
	if are.Param != "messages[0].content[0]" {
		t.Errorf("param=%q", are.Param)
	}
}

// TestContentParts_EmptyInputAudioRejected 空 input_audio.data 拒绝。
func TestContentParts_EmptyInputAudioRejected(t *testing.T) {
	_, _, err := OpenAIChatToGemini(chatWithParts(
		map[string]any{"type": "input_audio", "input_audio": map[string]any{"data": "", "format": "wav"}},
	), "gemini-2.5-flash", nil)
	are := mustAdapterRejected(t, err)
	if are.Param != "messages[0].content[0].input_audio.data" {
		t.Errorf("param=%q", are.Param)
	}
}

// TestTools_UnknownTypeRejected 未知 tool 类型拒绝（不再静默跳过）。
func TestTools_UnknownTypeRejected(t *testing.T) {
	req := &OpenAIChatRequest{
		Model:    "gemini-2.5-flash",
		Messages: []OpenAIMessage{{Role: "user", Content: "hi"}},
		Tools:    []OpenAITool{{Type: "web_search"}},
	}
	_, _, err := OpenAIChatToGemini(req, "gemini-2.5-flash", nil)
	are := mustAdapterRejected(t, err)
	if are.Param != "tools[0].type" {
		t.Errorf("param=%q", are.Param)
	}
	if !strings.Contains(are.Message, "unsupported tool type") {
		t.Errorf("message=%q", are.Message)
	}
}

// TestTools_EmptyNameRejected 空函数名拒绝且带 param。
func TestTools_EmptyNameRejected(t *testing.T) {
	req := &OpenAIChatRequest{
		Model:    "gemini-2.5-flash",
		Messages: []OpenAIMessage{{Role: "user", Content: "hi"}},
		Tools:    []OpenAITool{{Type: "function", Function: OpenAIFunctionDef{}}},
	}
	_, _, err := OpenAIChatToGemini(req, "gemini-2.5-flash", nil)
	are := mustAdapterRejected(t, err)
	if are.Param != "tools[0].function.name" {
		t.Errorf("param=%q", are.Param)
	}
}
