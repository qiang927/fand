//go:build !no_tokenizer

// Package tokenizer 提供与 Gemini 实际分词语义一致的本地 token 计数。
//
// Gemini 系列（2.0/2.5）与 Gemma 3 共用同一套 SentencePiece BPE 分词器——
// Google 官方 python-genai SDK 的本地分词器（google/genai/local_tokenizer.py）
// 正是加载 Gemma3 的 tokenizer.model 并对累积文本做裸编码求和。本包用同一份模型
// 文件（gemma3_cleaned_262144_v2.spiece.model）与纯 Go 的 BPE 解码器复现该行为，
// 使本地估算与上游实际计数几乎一致。
//
// 模型经 //go:embed 内嵌、首次使用时懒加载；加载失败或在不带模型的构建
// （-tags no_tokenizer）下自动回退到字符启发式，保证计数永不失败、不影响请求转发。
package tokenizer

import (
	"bytes"
	_ "embed"
	"log"
	"sync"

	sentencepiece "github.com/eliben/go-sentencepiece"
)

// gemma3Model 是 Google Gemma 3 的 SentencePiece BPE 模型（与 Gemini 2.0/2.5 同源），
// 取自 https://github.com/google/gemma_pytorch/tree/main/tokenizer
// （gemma3_cleaned_262144_v2.spiece.model，SHA-256
// 1299c11d7cf632ef3b4e11937501358ada021bbdf7c47638d13c0ee982f2e79c）。
//
//go:embed gemma3_cleaned_262144_v2.spiece.model
var gemma3Model []byte

//nolint:gochecknoglobals // 进程级单例：模型只加载一次、只读复用（Encode 并发安全）。
var (
	loadOnce sync.Once
	proc     *sentencepiece.Processor
)

// load 懒加载分词器；失败时保持 proc 为 nil，调用方回退启发式。
func load() {
	p, err := sentencepiece.NewProcessor(bytes.NewReader(gemma3Model))
	if err != nil {
		log.Printf("[Tokenizer] Gemini 分词器模型加载失败，本次回退字符启发式估算: %v", err)
		return
	}
	proc = p
}

// Count 返回 text 在 model 对应分词器下的 token 数。
//
// 分词器按模型所属世代选择（见 FamilyForModel）：
//   - FamilyGemma3：用内嵌的 Gemma3 SentencePiece 模型精确计数；
//   - FamilyGemma4 / FamilyUnknown：本程序未内嵌对应模型，回退字符启发式；
//   - 空串恒返回 0，与"空 contents 计 0"的既有口径一致。
//
// 不按名称前缀猜测分词器——只有显式映射到 gemma3 的模型才走内嵌模型。
func Count(model, text string) int {
	if text == "" {
		return 0
	}
	if FamilyForModel(model) != FamilyGemma3 {
		return HeuristicCount(text)
	}
	loadOnce.Do(load)
	if proc == nil {
		return HeuristicCount(text)
	}
	// Encode 只读模型、无共享可变状态，可安全并发调用（流式每 chunk 计数在并发路径上）。
	return len(proc.Encode(text))
}

// Available 报告真实分词器是否可用；供测试与诊断使用。
func Available() bool {
	loadOnce.Do(load)
	return proc != nil
}

// VocabSize 返回已加载词表大小；不可用时返回 0。
func VocabSize() int {
	loadOnce.Do(load)
	if proc == nil {
		return 0
	}
	return proc.ModelInfo().VocabularySize
}
