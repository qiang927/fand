//go:build no_tokenizer

// 本文件是 -tags no_tokenizer 的精简构建：不内嵌 Gemma3 模型（省下约 4.7MB
// 二进制体积与相应常驻内存），Count 直接走字符启发式。用于 Android/体积受限
// 的分发场景；除计数精度外，其余行为与默认构建完全一致。
package tokenizer

// Count 在 no_tokenizer 构建下恒走字符启发式估算（不内嵌任何分词器模型）。
func Count(model, text string) int {
	if text == "" {
		return 0
	}
	return HeuristicCount(text)
}

// Available 在 no_tokenizer 构建下恒为 false。
func Available() bool { return false }

// VocabSize 在 no_tokenizer 构建下恒为 0。
func VocabSize() int { return 0 }
