package tokenizer

import (
	"strings"
	"testing"
)

// gemma3TestModel 是内嵌分词器（Gemma3 世代）的示例模型名。
const gemma3TestModel = "gemini-2.5-flash"

// TestCountEmpty 空串恒为 0（任何构建、任何模型）。
func TestCountEmpty(t *testing.T) {
	for _, m := range []string{gemma3TestModel, "gemini-3.5-flash", "unknown-model"} {
		if got := Count(m, ""); got != 0 {
			t.Fatalf("Count(%q, \"\")=%d，期望 0", m, got)
		}
	}
}

// TestHeuristicCount 固定覆盖字符启发式兜底的口径（与优化前实现逐字节一致）。
func TestHeuristicCount(t *testing.T) {
	cases := []struct {
		name string
		in   string
		want int
	}{
		{"empty", "", 0},
		{"ascii short truncates", "abc", 0}, // 3/4 = 0
		{"ascii four", "abcd", 1},           // 4/4 = 1
		{"ascii words", "hello world", 2},   // 11/4 = 2
		{"chinese", "你好世界", 6},              // 4 + 4/2
		{"mixed", "Hello 你好", 4},            // 6/4=1 + 2+1=3
		{"emoji", "😀🎉", 3},                  // 2 + 1
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			if got := HeuristicCount(c.in); got != c.want {
				t.Errorf("HeuristicCount(%q)=%d，期望 %d", c.in, got, c.want)
			}
		})
	}
}

// TestFamilyForModel 覆盖 model → tokenizer 世代的显式映射：SDK 权威列表、
// 本仓库 models.json 的模型族，以及表外模型（必须为 unknown，不按名称猜测）。
func TestFamilyForModel(t *testing.T) {
	cases := []struct {
		model string
		want  Family
	}{
		// SDK 权威列表：gemma3（SentencePiece）
		{"gemini-2.5-pro", FamilyGemma3},
		{"gemini-2.5-flash", FamilyGemma3},
		{"gemini-2.5-flash-lite", FamilyGemma3},
		{"gemini-2.0-flash", FamilyGemma3},
		{"gemini-2.0-flash-lite", FamilyGemma3},
		{"gemini-3-pro-preview", FamilyGemma3},
		{"gemini-3-flash-preview", FamilyGemma3},
		// SDK 权威列表：gemma4（HuggingFace）
		{"gemini-3.5-flash", FamilyGemma4},
		{"gemini-3.1-flash-lite", FamilyGemma4},
		{"gemini-3.1-pro-preview", FamilyGemma4},
		// 本仓库 models.json：SDK 未收录但显式归属
		{"gemini-2.5-flash-image", FamilyGemma3},
		{"gemini-2.5-pro-tts", FamilyGemma3},
		{"gemini-3-pro-image", FamilyGemma3},
		{"gemini-3.1-flash-image", FamilyGemma4},
		{"gemini-3.1-flash-lite-image", FamilyGemma4},
		{"gemini-3.5-flash-lite", FamilyGemma4},
		{"gemini-3.6-flash", FamilyGemma4},
		{"gemini-3.7-flash", FamilyGemma4},
		{"gemini-3.8-flash", FamilyGemma4},
		{"gemini-4-argon", FamilyGemma4},
		// 表外模型：显式 unknown（不猜测）
		{"gemini-nano-banana-2.1", FamilyUnknown},
		{"gemini-omni-flash-preview", FamilyUnknown},
		{"some-random-model", FamilyUnknown},
		{"", FamilyUnknown},
	}
	for _, c := range cases {
		t.Run(c.model, func(t *testing.T) {
			if got := FamilyForModel(c.model); got != c.want {
				t.Errorf("FamilyForModel(%q)=%q，期望 %q", c.model, got, c.want)
			}
		})
	}
}

// TestCountModelSelection 校验按模型选择分词器：只有 gemma3 世代走内嵌模型，
// gemma4 / unknown 一律回退启发式（不误用 gemma3 口径）。
func TestCountModelSelection(t *testing.T) {
	texts := []string{"hello world", "你好世界", "Hello 你好 world", "😀"}

	for _, m := range []string{"gemini-3.5-flash", "gemini-3.1-pro-preview", "gemini-4-argon", "unknown-model"} {
		for _, s := range texts {
			if got, want := Count(m, s), HeuristicCount(s); got != want {
				t.Errorf("非 gemma3 模型 %q 应回退启发式：Count=%d，HeuristicCount=%d", m, got, want)
			}
		}
	}

	if !Available() {
		// no_tokenizer 构建：gemma3 模型也回退启发式。
		for _, s := range texts {
			if got, want := Count(gemma3TestModel, s), HeuristicCount(s); got != want {
				t.Errorf("no_tokenizer 构建下 gemma3 模型应回退启发式：Count=%d，want %d", got, want)
			}
		}
	}
}

// TestCountGemini 覆盖中英文、混合文本、代码、特殊字符等典型输入的真实分词计数。
// 仅在默认构建（分词器可用）下断言精确值。
func TestCountGemini(t *testing.T) {
	if !Available() {
		t.Skip("no_tokenizer 构建：跳过真实分词器精确值断言")
	}

	cases := []struct {
		name string
		in   string
		want int
	}{
		{"english sentence", "The quick brown fox jumps over the lazy dog.", 10},
		{"english short", "hello world", 2},
		{"chinese", "你好世界", 2},
		{"chinese sentence", "你好，世界！这是一个测试。", 7},
		{"mixed zh en", "Hello 你好 world 世界", 5},
		{"code", `func main() { fmt.Println("hi") }`, 11},
		{"json", `{"a":1,"b":[true,null,"x"]}`, 13},
		{"emoji", "😀🎉🚀 emoji test ❤️", 6},
		{"single char", "a", 1},
		{"two chars", "ab", 1},
		{"whitespace and newlines", "line1\nline2\ttab", 7},
		{"leading trailing spaces", "  leading and trailing  ", 5},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			if got := Count(gemma3TestModel, c.in); got != c.want {
				t.Errorf("Count(%q)=%d，期望 %d", c.in, got, c.want)
			}
		})
	}
}

// TestCountRobustness 校验异常/边界输入不 panic 且非负：控制字符、无效 UTF-8、
// 组合字符、超长重复文本。
func TestCountRobustness(t *testing.T) {
	inputs := []string{
		"\x00\x01\x02 control chars",
		string([]byte{0xff, 0xfe, 0xfd}), // 无效 UTF-8 字节序列
		"e\u0301\u0301\u0301",            // 组合重音
		strings.Repeat("测试abc123", 500),
		"\u200b\u200b", // 零宽空格
	}
	for i, in := range inputs {
		got := Count(gemma3TestModel, in)
		if got < 0 {
			t.Errorf("输入 #%d Count=%d 为负", i, got)
		}
		// 确定性：同输入同输出。
		if again := Count(gemma3TestModel, in); again != got {
			t.Errorf("输入 #%d 计数不确定：%d != %d", i, got, again)
		}
	}
}

// TestCountMonotonic 长度更长的同类文本 token 数不应减少（分词器基本性质，防止回归）。
func TestCountMonotonic(t *testing.T) {
	short := "The weather in Paris is"
	long := "The weather in Paris is sunny and warm today with a light breeze"
	if Count(gemma3TestModel, long) < Count(gemma3TestModel, short) {
		t.Errorf("更长文本 token 数更少：long=%d short=%d",
			Count(gemma3TestModel, long), Count(gemma3TestModel, short))
	}
}

// TestVocabSize 校验默认构建下加载的是 Gemma3 262144 词表。
func TestVocabSize(t *testing.T) {
	if !Available() {
		if VocabSize() != 0 {
			t.Fatalf("no_tokenizer 构建 VocabSize=%d，期望 0", VocabSize())
		}
		return
	}
	if got := VocabSize(); got != 262144 {
		t.Fatalf("VocabSize=%d，期望 262144（Gemma3 词表）", got)
	}
}

// TestCountConcurrent 校验 Encode 并发安全：并发计数结果与串行一致（流式每 chunk 计数的路径）。
func TestCountConcurrent(t *testing.T) {
	texts := []string{
		"hello world", "你好世界", `{"k":"v"}`, "😀🎉", "line\nbreak",
	}
	serial := make([]int, len(texts))
	for i, s := range texts {
		serial[i] = Count(gemma3TestModel, s)
	}

	const workers = 32
	done := make(chan struct{})
	for w := 0; w < workers; w++ {
		go func() {
			defer func() { done <- struct{}{} }()
			for i, s := range texts {
				if got := Count(gemma3TestModel, s); got != serial[i] {
					t.Errorf("并发计数不一致：Count(%q)=%d，串行=%d", s, got, serial[i])
					return
				}
			}
		}()
	}
	for w := 0; w < workers; w++ {
		<-done
	}
}
