package tokenizer

// HeuristicCount 是字符类启发式估算，作为真实分词器不可用时的兜底。
//
// 口径（与优化前的实现逐字节一致）：
//   - ASCII 字符：每 4 字符 1 token（len(ascii) / 4）
//   - 非 ASCII 字符（中文/日韩/Emoji 等）：每字符 1.5 token（n + n/2）
//
// 它按字符脚本粗略折算，对代码、符号、Emoji 的偏差明显，故仅在无法加载
// Gemini 分词器模型时使用；正常构建一律走真实分词器。
func HeuristicCount(text string) int {
	ascii := 0
	nonAscii := 0
	for _, r := range text {
		if r <= 127 {
			ascii++
		} else {
			nonAscii++
		}
	}
	return ascii/4 + nonAscii + nonAscii/2
}
