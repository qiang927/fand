package tokenizer

// Family 标识一个模型所属的 Gemini tokenizer 世代（模型 → 分词器归属）。
type Family string

const (
	// FamilyGemma3 是 Gemini 2.0/2.5 世代（含 gemini-3-pro/flash-preview）使用的
	// SentencePiece 分词器。本程序内嵌该模型，计数与上游语义一致。
	FamilyGemma3 Family = "gemma3"
	// FamilyGemma4 是 Gemini 3.1/3.5+ 世代使用的 HuggingFace 分词器。gemma_pytorch
	// 不再提供 gemma4 的 SentencePiece 文件，本程序未内嵌，计数回退启发式。
	FamilyGemma4 Family = "gemma4"
	// FamilyUnknown 是无公开 tokenizer 归属的模型（本地自定义/未来模型等）。
	// 显式标为 unknown 而非按名称猜成 gemma3，避免用错口径；计数回退启发式。
	FamilyUnknown Family = "unknown"
)

// gemma3Models / gemma4Models 是**显式枚举**的模型 → 分词器映射，不做名称前缀猜测。
//
// 权威来源：Google 官方 python-genai SDK 的 google/genai/_local_tokenizer_loader.py
// （v2.30.1）：
//   - _GEMINI_MODELS_TO_TOKENIZER_NAMES / _GEMINI_STABLE_MODELS_TO_TOKENIZER_NAMES
//     → gemma3（SentencePiece）；
//   - _GEMINI_MODELS_TO_HUGGINGFACE_TOKENIZER_NAMES → gemma4（HuggingFace）。
//
// 其后一段是本仓库 config/models.json 中 SDK 未收录的模型：按世代显式归属并注明
// 依据，仍属显式声明而非前缀推断。表外模型一律 FamilyUnknown。
//
//nolint:gochecknoglobals // 只读的显式映射表，进程级常量。
var gemma3Models = map[string]struct{}{
	// —— SDK 权威列表（Gemini 2.0/2.5 世代，含 3-pro/flash-preview）——
	"gemini-2.5-pro":                      {},
	"gemini-2.5-flash":                    {},
	"gemini-2.5-flash-lite":               {},
	"gemini-2.0-flash":                    {},
	"gemini-2.0-flash-lite":               {},
	"gemini-2.5-pro-preview-06-05":        {},
	"gemini-2.5-pro-preview-05-06":        {},
	"gemini-2.5-pro-exp-03-25":            {},
	"gemini-live-2.5-flash":               {},
	"gemini-2.5-flash-preview-05-20":      {},
	"gemini-2.5-flash-preview-04-17":      {},
	"gemini-2.5-flash-lite-preview-06-17": {},
	"gemini-2.0-flash-001":                {},
	"gemini-2.0-flash-lite-001":           {},
	"gemini-3-pro-preview":                {},
	"gemini-3-flash-preview":              {},
	// —— 本仓库 models.json：SDK 未收录，按"2.5/3.0 世代"显式归属 ——
	"gemini-2.5-flash-image": {}, // 2.5 世代的文本分词器；媒体部分另按固定折算
	"gemini-2.5-flash-tts":   {},
	"gemini-2.5-pro-tts":     {},
	"gemini-3-pro-image":     {}, // 与 gemini-3-pro-preview 同为 3.0 世代
}

//nolint:gochecknoglobals // 只读的显式映射表，进程级常量。
var gemma4Models = map[string]struct{}{
	// —— SDK 权威列表（HuggingFace 分词器）——
	"gemini-3.5-flash":       {},
	"gemini-3.1-flash-lite":  {},
	"gemini-3.1-pro-preview": {},
	// —— 本仓库 models.json：SDK 未收录，按"3.1/3.5+ 世代"显式归属 ——
	"gemini-3.1-flash-image":         {},
	"gemini-3.1-flash-image-preview": {},
	"gemini-3.1-flash-lite-image":    {},
	"gemini-3.1-flash-tts-preview":   {},
	"gemini-3.5-flash-lite":          {},
	"gemini-3.6-flash":               {},
	"gemini-3.7-flash":               {},
	"gemini-3.8-flash":               {},
	"gemini-4-argon":                 {}, // 本地自定义 4 世代模型：显式归属 gemma4，不按名称猜测
}

// FamilyForModel 返回模型所属的 tokenizer 世代；表外模型返回 FamilyUnknown。
func FamilyForModel(model string) Family {
	if _, ok := gemma3Models[model]; ok {
		return FamilyGemma3
	}
	if _, ok := gemma4Models[model]; ok {
		return FamilyGemma4
	}
	return FamilyUnknown
}
