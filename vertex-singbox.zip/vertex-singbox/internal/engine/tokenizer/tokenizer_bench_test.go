package tokenizer

import (
	"strings"
	"testing"
)

// 用于基准的代表性输入：英文、中文、混合、代码、JSON、Emoji 与流式短 chunk。
//
//nolint:gochecknoglobals // 基准输入是只读常量，提到包级避免每次迭代重建。
var (
	benchEnglish = strings.Repeat("The quick brown fox jumps over the lazy dog. ", 8)
	benchChinese = strings.Repeat("你好，世界！这是一个用于分词基准测试的中文句子。", 8)
	benchMixed   = strings.Repeat("Hello 你好 world 世界 123 !@# ", 8)
	benchCode    = strings.Repeat("func main() { if x := f(a, b); x != nil { return x } }\n", 8)
	benchJSON    = strings.Repeat(`{"role":"user","parts":[{"text":"hi"}],"n":42}`, 8)
	benchEmoji   = strings.Repeat("😀🎉🚀❤️ ", 16)
	// 流式增量：真实 chunk 通常只含数个字符，是计数热路径。
	benchChunk = "你好"
)

func benchmarkCount(b *testing.B, model, text string) {
	b.ReportAllocs()
	b.SetBytes(int64(len(text)))
	for i := 0; i < b.N; i++ {
		_ = Count(model, text)
	}
}

func BenchmarkCountEnglish(b *testing.B)     { benchmarkCount(b, gemma3TestModel, benchEnglish) }
func BenchmarkCountChinese(b *testing.B)     { benchmarkCount(b, gemma3TestModel, benchChinese) }
func BenchmarkCountMixed(b *testing.B)       { benchmarkCount(b, gemma3TestModel, benchMixed) }
func BenchmarkCountCode(b *testing.B)        { benchmarkCount(b, gemma3TestModel, benchCode) }
func BenchmarkCountJSON(b *testing.B)        { benchmarkCount(b, gemma3TestModel, benchJSON) }
func BenchmarkCountEmoji(b *testing.B)       { benchmarkCount(b, gemma3TestModel, benchEmoji) }
func BenchmarkCountStreamChunk(b *testing.B) { benchmarkCount(b, gemma3TestModel, benchChunk) }

// BenchmarkCountGemma4Fallback 是对照：gemma4 世代模型（未内嵌）走启发式回退。
func BenchmarkCountGemma4Fallback(b *testing.B) { benchmarkCount(b, "gemini-3.5-flash", benchEnglish) }

// BenchmarkHeuristic 作为对照基线：同输入的字符启发式耗时。
func BenchmarkHeuristicEnglish(b *testing.B) {
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_ = HeuristicCount(benchEnglish)
	}
}
