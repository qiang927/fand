package vertex

import (
	"testing"

	"github.com/bsfdsagfadg/vertex/internal/engine/tokenizer"
	"github.com/bsfdsagfadg/vertex/internal/engine/transform"
)

// ---- 本地分词计数测试（强类型 contents）----
//
// 媒体 Part 的固定折算与结构不变量在任何构建下都成立；纯文本的精确值取决于
// 模型所属分词器世代（gemma3 走内嵌模型，其余回退启发式）与构建标签
// （-tags no_tokenizer 恒为启发式），故按可用性选期望。

// gemma3Model 是内嵌分词器世代的示例模型（2.5 世代）。
const gemma3Model = "gemini-2.5-flash"

func TestEstimateTokens(t *testing.T) {
	realTok := tokenizer.Available()
	// want 按 (真实分词器, 启发式兜底) 两套期望取值。
	want := func(real, fallback int) int {
		if realTok {
			return real
		}
		return fallback
	}

	cases := []struct {
		name     string
		contents []transform.Content
		want     int
	}{
		{
			name:     "empty contents",
			contents: nil,
			want:     0,
		},
		{
			name: "ascii only text",
			contents: []transform.Content{{Parts: []transform.Part{
				{Text: "hello world"},
			}}},
			want: want(2, 2),
		},
		{
			name: "non-ascii text (Chinese)",
			contents: []transform.Content{{Parts: []transform.Part{
				{Text: "你好世界"},
			}}},
			// Gemini 分词器对常用中文约 1 token/2 字；启发式按 1.5 token/字高估。
			want: want(2, 6),
		},
		{
			name: "mixed ascii and non-ascii",
			contents: []transform.Content{{Parts: []transform.Part{
				{Text: "Hello 你好"},
			}}},
			want: want(3, 4),
		},
		{
			name: "inlineData media adds 1024",
			contents: []transform.Content{{Parts: []transform.Part{
				{InlineData: &transform.InlineData{MimeType: "image/png", Data: "abc"}},
			}}},
			want: 1024,
		},
		{
			name: "fileData media adds 1024",
			contents: []transform.Content{{Parts: []transform.Part{
				{FileData: &transform.FileData{MimeType: "image/jpeg", FileURI: "gs://bucket/img.jpg"}},
			}}},
			want: 1024,
		},
		{
			name: "text + inlineData combined",
			contents: []transform.Content{{Parts: []transform.Part{
				{Text: "Describe this image"},
				{InlineData: &transform.InlineData{MimeType: "image/png", Data: "xyz"}},
			}}},
			want: want(3, 4) + 1024,
		},
		{
			name: "multiple contents",
			contents: []transform.Content{
				{Parts: []transform.Part{{Text: "hi"}}},
				{Parts: []transform.Part{{Text: "hello"}}},
			},
			want: want(2, 1),
		},
		{
			name: "inlineData wins over fileData",
			contents: []transform.Content{{Parts: []transform.Part{
				{InlineData: &transform.InlineData{MimeType: "image/png", Data: "a"}, FileData: &transform.FileData{FileURI: "gs://b"}},
			}}},
			// 旧语义：inlineData 存在即 1024（else-if 链）
			want: 1024,
		},
		{
			name: "empty string text counts 0",
			contents: []transform.Content{{Parts: []transform.Part{
				{Text: ""},
			}}},
			want: 0,
		},
	}

	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			if got := estimateTokensTyped(gemma3Model, c.contents); got != c.want {
				t.Errorf("estimateTokensTyped=%d，期望 %d", got, c.want)
			}
		})
	}
}

// TestEstimateRequestTokens 覆盖输入侧计数包含 systemInstruction 与 tools，
// 且大于等于仅 contents 的计数。
func TestEstimateRequestTokens(t *testing.T) {
	req := &transform.GeminiRequest{
		Contents: []transform.Content{{Parts: []transform.Part{{Text: "hello world"}}}},
		SystemInstruction: &transform.Content{
			Parts: []transform.Part{{Text: "You are a helpful assistant."}},
		},
		Tools: []transform.Tool{{
			FunctionDeclarations: []transform.FunctionDeclaration{{
				Name:        "get_weather",
				Description: "Get the current weather for a city.",
				Parameters:  map[string]any{"type": "object", "properties": map[string]any{"city": map[string]any{"type": "string"}}},
			}},
		}},
	}

	base := estimateTokensTyped(gemma3Model, req.Contents)
	got := EstimateRequestTokens(gemma3Model, req)
	if got <= base {
		t.Fatalf("EstimateRequestTokens=%d 应大于仅 contents 的 %d（含 system+tools）", got, base)
	}

	// nil 请求返回 0，不得 panic。
	if EstimateRequestTokens(gemma3Model, nil) != 0 {
		t.Fatalf("nil 请求应返回 0")
	}
}

// TestEstimateTokensDeterministic 保证同一输入多次计数一致（分词器无隐藏可变状态）。
func TestEstimateTokensDeterministic(t *testing.T) {
	contents := []transform.Content{{Parts: []transform.Part{{Text: "你好 world 123 !@#"}}}}
	first := estimateTokensTyped(gemma3Model, contents)
	for i := 0; i < 5; i++ {
		if got := estimateTokensTyped(gemma3Model, contents); got != first {
			t.Fatalf("第 %d 次计数=%d，与首次 %d 不一致", i, got, first)
		}
	}
}
