package vertex

import (
	"context"
	"encoding/json"
	"log"

	"github.com/bsfdsagfadg/vertex/internal/engine/tokenizer"
	"github.com/bsfdsagfadg/vertex/internal/engine/transform"
)

// CountTokens 统计给定 contents 在指定模型下的 token 数（纯本地离线计数）。
//
// 分词器按模型所属世代选择（见 internal/engine/tokenizer）：Gemini 2.0/2.5 世代
// 用内嵌的 Gemma3 SentencePiece 模型精确计数（语义对齐 Google 官方 python-genai 的
// 本地分词器：对文本 Part 做裸编码求和，不插入轮次标记）；其余世代/未知模型回退字符
// 启发式。媒体 Part 固定折算 1024 token（官方本地分词器对媒体直接报错，此处仅作统计用，
// 不影响转发）。
//
// 返回计数值，0 表示空 contents。
func (c *VertexAIClient) CountTokens(_ context.Context, model string, contents []transform.Content) int {
	result := estimateTokensTyped(model, contents)
	if c.cfg.DebugMode() {
		log.Printf("[Vertex] [CountTokens] 本地计数: 模型=%s(%s), tokens=%d", model, tokenizer.FamilyForModel(model), result)
	}
	return result
}

// EstimatePartsTokens 对 parts 做本地 token 计数（导出给 api 层统计输出用量）。
// 与 CountTokens 使用同一套按模型选择的分词器口径，保证输入/输出两侧一致。
func EstimatePartsTokens(model string, parts []transform.Part) int {
	return estimatePartsTokensTyped(model, parts)
}

// EstimateRequestTokens 计数一次请求的输入 token：contents + systemInstruction + tools。
// 匿名端点不回 usageMetadata，输入侧只能本地计数；遗漏 systemInstruction/tools 会系统性低估。
func EstimateRequestTokens(model string, req *transform.GeminiRequest) int {
	if req == nil {
		return 0
	}
	total := estimateTokensTyped(model, req.Contents)
	if req.SystemInstruction != nil {
		total += estimatePartsTokensTyped(model, req.SystemInstruction.Parts)
	}
	for _, t := range req.Tools {
		total += estimateToolTokens(model, t)
	}
	return total
}

// estimateToolTokens 估算单个工具声明的 token 开销（函数名/描述/参数 schema 序列化）。
func estimateToolTokens(model string, t transform.Tool) int {
	total := 0
	for _, fd := range t.FunctionDeclarations {
		total += estimateTextTokens(model, fd.Name)
		total += estimateTextTokens(model, fd.Description)
		total += estimateJSONTokens(model, fd.Parameters)
	}
	// 内置工具（googleSearch / codeExecution 等）无显式声明体，按固定开销估算。
	if t.GoogleSearch != nil || t.GoogleSearchRetrieval != nil || t.CodeExecution != nil ||
		t.Retrieval != nil || t.URLContext != nil || t.ComputerUse != nil ||
		t.MCPTool != nil || t.FileSearch != nil || t.GoogleMaps != nil {
		total += 32
	}
	return total
}

// estimateTokensTyped 对强类型 contents 进行纯本地 token 计数（零 map 中转）。
func estimateTokensTyped(model string, contents []transform.Content) int {
	total := 0
	for _, cm := range contents {
		total += estimatePartsTokensTyped(model, cm.Parts)
	}
	return total
}

// estimatePartsTokensTyped 统计单个 content 内 parts 的 token 计数。
// 覆盖文本、内联/文件媒体，以及工具调用、工具结果、可执行代码等结构化 part，
// 避免"纯 functionCall 响应"被折算成 0 输出 token。
func estimatePartsTokensTyped(model string, parts []transform.Part) int {
	total := 0
	for _, p := range parts {
		if p.Text != "" {
			total += estimateTextTokens(model, p.Text)
		}
		if p.InlineData != nil {
			total += 1024
		} else if p.FileData != nil {
			total += 1024
		}
		if p.FunctionCall != nil {
			total += estimateTextTokens(model, p.FunctionCall.Name)
			total += estimateJSONTokens(model, p.FunctionCall.Args)
		}
		if p.FunctionResponse != nil {
			total += estimateTextTokens(model, p.FunctionResponse.Name)
			total += estimateJSONTokens(model, p.FunctionResponse.Response)
		}
		if p.ExecutableCode != nil {
			total += estimateTextTokens(model, p.ExecutableCode.Code)
			total += estimateTextTokens(model, p.ExecutableCode.CodeLanguage)
		}
		if p.CodeExecutionResult != nil {
			total += estimateTextTokens(model, p.CodeExecutionResult.Output)
		}
	}
	return total
}

// estimateJSONTokens 估算任意值序列化后的 token 数；nil 返回 0，字符串直接按文本折算。
//
// 边界说明：此处用 json.Marshal 后整体计数，与 Google 官方 LocalTokenizer 的
// accumulator（逐项收集 schema 描述/键名）并非逐字节一致；工具/schema 的计数精度
// 属后续优化项，见 PR 说明。
func estimateJSONTokens(model string, v any) int {
	if v == nil {
		return 0
	}
	if s, ok := v.(string); ok {
		return estimateTextTokens(model, s)
	}
	b, err := json.Marshal(v)
	if err != nil {
		return 0
	}
	return estimateTextTokens(model, string(b))
}

// estimateTextTokens 用模型对应的 Gemini 分词器统计文本 token 数。
// 非 gemma3 世代/未知模型由 tokenizer.Count 内部回退字符启发式。
func estimateTextTokens(model, text string) int {
	return tokenizer.Count(model, text)
}
