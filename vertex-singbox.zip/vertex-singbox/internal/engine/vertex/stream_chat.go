package vertex

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"strconv"
	"strings"
	"sync/atomic"
	"time"

	"github.com/bsfdsagfadg/vertex/internal/engine/transform"
	"github.com/bsfdsagfadg/vertex/internal/infra/spool"
	"github.com/bsfdsagfadg/vertex/internal/infra/transport"
)

// ErrStreamIdleTimeout 是流式包间空闲超时哨兵错误。
// 首包前触发会自动重试/故障转移；首包后触发向客户端推送超时 error chunk。
var ErrStreamIdleTimeout = errors.New("stream idle timeout")

// ErrStreamIncomplete 是流在未收到任何真实 finishReason 前即结束的哨兵错误
// （上游干净 EOF 但未按匿名端点契约给出终帧，或元数据后直接收尾）。
// 交付层遇此错误必须向客户端透传"截断"语义，严禁补发 FinishReason=STOP 冒充完整生成。
var ErrStreamIncomplete = errors.New("stream ended without finish reason")

// sessionTimeoutFromContext 从 context 的 deadline 推导 Session 的超时秒数。
// 至少返回 1 秒（tls-client.WithTimeoutSeconds 只接受正秒），但 context 的 deadline
// 仍由 Session.Do 优先检查；该值仅用于构造传输层超时。
func sessionTimeoutFromContext(ctx context.Context, defaultSec int) int {
	if d, ok := ctx.Deadline(); ok {
		rem := time.Until(d)
		if rem <= 0 {
			return 1
		}
		sec := int(rem.Seconds())
		if sec < 1 {
			return 1
		}
		return sec
	}
	return defaultSec
}

// StreamChunk 是真流式中 yield 的单个增量。要么是 Gemini 数据 chunk，要么是错误。
type StreamChunk struct {
	// Data 是清洗后的 Gemini 增量（candidates/usageMetadata/...），Err==nil 时有效。
	Data *transform.GeminiChunk
	// Err 非 nil 表示重试耗尽、对外报错。
	Err *VertexError
}

// StreamChat 真流式入口。
func (c *VertexAIClient) StreamChat(ctx context.Context, model string, req *transform.GeminiRequest, yield func(StreamChunk) bool, strategy transform.ModelStrategy) {
	if strategy == nil {
		strategy = transform.SharedModelFamilyRouter().For(model)
	}
	// 预取池自停解除点，每请求通知一次：竞速的 N 个候选各自取 token、StreamChatCollect
	// 又会嵌套调用本函数，重复通知由池内按 reqID 合并。
	c.pool.NoteRequest(RequestIDFromContext(ctx))
	// L1 透传层：单候选一次尝试，原样上报真实错误（不重试、不分类、不转换）。
	// 每轮独立建连 + 独立取 token（两者并行执行，见 prepareCandidate）；
	// 首帧已交付后断流时对错误标 Truncated（Committed 语义）。
	op := func(ctx context.Context, proxyURI string) <-chan StreamChunk {
		ch := make(chan StreamChunk, 64)
		go func() {
			defer close(ch)
			// 请求级时序（胜出值落点）与候选级时序（本候选首字节）分离：
			// 竞速下未胜出的候选也会读到字节，若直接取全候选最早值会偏乐观。
			reqTiming := TimingFromContext(ctx)
			candTiming := NewUpstreamTiming()
			attemptCtx := WithUpstreamTiming(ctx, candTiming)

			// sendErr 与 emit 同规：带 ctx 保护的收尾发送。收尾错误帧（空响应/终局错误）
			// 若无条件发往 ch，会在 ch(64) 被背压填满且 attemptCtx 已取消（客户端断开）
			// 时永久阻塞——defer close(ch)/sess.Close()/buf.Close() 全部不执行，
			// 转发 goroutine 与 spool 临时文件随之泄漏。
			sendErr := func(ve *VertexError) {
				select {
				case ch <- StreamChunk{Err: ve}:
				case <-attemptCtx.Done():
				}
			}

			sess, tok, err := c.prepareCandidate(attemptCtx, proxyURI)
			if err != nil {
				sendErr(err)
				return
			}
			defer sess.Close()
			var contentYielded bool
			emit := func(chunk *transform.GeminiChunk) bool {
				if strategy.IsValidChunk(chunk) {
					contentYielded = true
					// 首个产出有效内容的候选即胜出者（与 StreamParallel 的锁定口径一致），
					// CAS 保证后续候选不会覆写。
					reqTiming.MarkWinner(candTiming)
				}
				select {
				case ch <- StreamChunk{Data: chunk}:
					return true
				case <-attemptCtx.Done():
					return false
				}
			}
			attemptErr := withRTFirstTryCompensation(attemptCtx, c.rtCompensationDelay(), func() error {
				return c.executeStreamingAttempt(attemptCtx, sess, model, req, tok, emit, strategy)
			})
			if attemptErr == nil {
				if !contentYielded {
					sendErr(NewEmptyResponseError("Upstream returned empty response (no content)", nil))
				}
				return
			}
			ve := NormalizeError(attemptErr)
			if contentYielded {
				ve.WithTruncated()
			}
			sendErr(ve)
		}()
		return ch
	}
	StreamParallel(ctx, c.nodePool(), c.cfg, model, op, yield, strategy)
}

// executeStreamingAttempt 执行单次流式请求：发请求 → 增量扫描 JSON → 提取 chunk → 过滤 finishReason。
//
// emit 回调把清洗后的 Gemini chunk 推给上层；
// emit 始终返回 true；客户端断开由 ctx 取消触发 read 报错，scanStream 干净结束。
// ctx 绑定 to 上游流连接：ctx 取消时 Body.Read 报错，scanStream 干净结束（返回 nil，不 panic）。
func (c *VertexAIClient) executeStreamingAttempt(ctx context.Context, sess *transport.Session, model string, req *transform.GeminiRequest, recaptchaToken string, emit func(*transform.GeminiChunk) bool, strategy transform.ModelStrategy) error {
	reqID := RequestIDFromContext(ctx)
	cfg := c.cfg
	if strategy == nil {
		strategy = transform.SharedModelFamilyRouter().For(model)
	}
	if cfg.DebugMode() {
		log.Printf("[Vertex] [executeStreamingAttempt] 准备发送流式请求: 模型=%s, 请求ID=%s, 代理=%s", model, reqID, c.nodePool().NodeName(sess.ProxyURI))
	}
	newBody := buildTypedRequestPayload(model, req, recaptchaToken, cfg)
	// 上游请求 payload 序列化到 spool 缓冲（大媒体自动落盘）。流式：请求体在 DoStream 发送期被读取，
	// 缓冲存活到本函数返回（整个流消费完）后由 defer Close 删除临时文件。
	buf, err := spool.EncodeJSON(newBody)
	if err != nil {
		return NewInternalError("marshal payload: "+err.Error(), nil)
	}
	defer func() { _ = buf.Close() }()
	reader, err := buf.Reader()
	if err != nil {
		return NewInternalError("spool reader: "+err.Error(), nil)
	}
	header := transport.XHRHeaders(
		"application/json", "*/*",
		"https://console.cloud.google.com", "https://console.cloud.google.com/", "cross-site",
	)

	// ═══ 流式包间空闲超时监控（前置版：覆盖 DoStream 等待阶段） ═══
	streamReqCtx, cancelStreamReq := context.WithCancel(ctx)
	defer cancelStreamReq()

	preTimeout, postTimeout := strategy.CalculateIdleTimeouts(cfg.StreamIdleTimeoutSeconds())

	var (
		srRef              atomic.Pointer[transport.StreamResponse]
		lastActiveUnixNano atomic.Int64
		hasReceivedFirst   atomic.Bool
		idleTriggered      atomic.Bool
	)
	lastActiveUnixNano.Store(time.Now().UnixNano())

	// timing 是本次尝试（候选级）的上游首字节采集器：优先用闭包注入的实例，
	// 未注入时（如单测直调）退回从 ctx 取，取不到则新建一个仅本地生效的。
	timing := TimingFromContext(streamReqCtx)
	if timing == nil {
		timing = NewUpstreamTiming()
	}

	touchActivity := func() {
		now := time.Now().UnixNano()
		lastActiveUnixNano.Store(now)
		// 仅在首次置位成功时才记录时刻：touchActivity 每次读到字节都会触发，
		// 无条件覆写会把它变成"最后一个字节"而非"第一个字节"。
		if !hasReceivedFirst.Load() {
			if hasReceivedFirst.CompareAndSwap(false, true) {
				timing.MarkFirstByte(now)
			}
		}
	}

	done := make(chan struct{})
	defer close(done)
	go func() {
		ticker := time.NewTicker(1 * time.Second)
		defer ticker.Stop()

		for {
			select {
			case <-ticker.C:
				last := time.Unix(0, lastActiveUnixNano.Load())
				elapsed := time.Since(last)

				timeout := preTimeout
				if hasReceivedFirst.Load() {
					timeout = postTimeout
				}

				if elapsed > timeout {
					if idleTriggered.CompareAndSwap(false, true) {
						log.Printf("[Vertex] [Stream] 触发流包间空闲超时 (已静默 %v > 阈值 %v), 切断连接, 请求ID=%s", elapsed.Round(time.Millisecond), timeout, reqID)
						cancelStreamReq()
						if sr := srRef.Load(); sr != nil {
							sr.Abort()
						}
					}
					return
				}
			case <-ctx.Done():
				cancelStreamReq()
				if sr := srRef.Load(); sr != nil {
					sr.Abort()
				}
				return
			case <-done:
				return
			}
		}
	}()
	// ═══════════════════════════════════════════════════════════════

	sr, err := sess.DoStream(streamReqCtx, "POST", c.getBatchGraphqlURL(), header, reader)
	if err != nil {
		if idleTriggered.Load() {
			return NewNetworkError(ErrStreamIdleTimeout)
		}
		return classifyNetworkError(err)
	}

	srRef.Store(sr)
	if idleTriggered.Load() {
		sr.Abort()
		return NewNetworkError(ErrStreamIdleTimeout)
	}
	defer sr.Close() // 排干 → close，防串流。

	// HTTP 错误：读完 error body 后按状态映射（与非流式 executeCompleteRequest 一致）。
	if sr.StatusCode != 200 {
		var buf bytes.Buffer
		_, _ = buf.ReadFrom(sr.Body)
		errText := buf.String()
		if cfg.DebugMode() {
			debugReq, _ := json.Marshal(newBody)
			log.Printf("[DEBUG] [StreamChat] HTTP 报错! 状态码: %d", sr.StatusCode)
			log.Printf("[DEBUG] [StreamChat] 完整请求体: %s", string(debugReq))
			log.Printf("[DEBUG] [StreamChat] 上游回复: %s", errText)
		} else if sr.StatusCode == 400 {
			debugBody, _ := json.Marshal(newBody.Variables)
			log.Printf("[Vertex] [Stream] 收到 400 Bad Request, Variables Payload: %s", string(debugBody))
			log.Printf("[Vertex] [Stream] 上游 400 原始回复: %s", errText)
		}

		// 认证/权限判定顺序：明确 rT 信号文本 → 结构化错误体 → HTTP 状态兜底。
		// 两条 rT 信号文本必须保持 Kind="auth"：isAuthVerifyFail 的同 token 补偿重试
		// 依赖该判定（见下 withRTFirstTryCompensation）。
		// 此前 403 在解析错误体之前就被一律判成 auth，而 parseErrorResponse 本可区分
		// PERMISSION_DENIED（模型/区域权限）与 UNAUTHENTICATED；误判会把健康节点经
		// applyNodeFailure 的 auth 分支禁用，且 BatchUpdateNodesDisabled 清掉
		// DisabledByHealth 后连"测速成功自动恢复"都失效。无法解析时按状态兜底：
		// 401 → auth、403 → permission（raiseForStatus 的既有映射）。
		if strings.Contains(errText, "Failed to verify action") ||
			strings.Contains(errText, "The caller does not have permission") {
			return NewAuthenticationError("Authentication/Recaptcha failed: "+errText, nil)
		}
		// 解析上游 Retry-After 头（429 限流建议退避时长），透传到客户端响应。
		retryAfter := parseRetryAfterHeader(sr.Header)
		if parsed := parseErrorResponse(errText); parsed != nil {
			parsed.UpstreamResponse = errText
			if sr.StatusCode == 429 && retryAfter > 0 {
				parsed.RetryAfter = retryAfter
			}
			return parsed
		}
		e := raiseForStatus(sr.StatusCode, "", "Upstream Error: "+errText, nil, errText)
		if sr.StatusCode == 429 && retryAfter > 0 {
			e.RetryAfter = retryAfter
		}
		return e
	}

	// 增量扫描上游流，逐个完整 JSON 对象提取 chunk。
	var seenFinish bool

	emitSink := emit
	if cfg.DebugMode() {
		emitSink = func(ch *transform.GeminiChunk) bool {
			log.Printf("[DEBUG] [Stream] 转发帧, 请求ID=%s, 节点=%s", reqID, c.nodePool().NodeName(sess.ProxyURI))
			return emit(ch)
		}
	}

	scanErr := scanStream(streamReqCtx, sr.Body, func(raw []byte) (stop bool, err error) {
		if cfg.DebugMode() {
			log.Printf("[DEBUG] [Stream] 上游帧摘要: %s, 请求ID=%s, 节点=%s", summarizeUpstreamObject(parseJSONObject(raw)), reqID, c.nodePool().NodeName(sess.ProxyURI))
		}
		return processStreamingObject(raw, emitSink, &seenFinish)
	}, touchActivity)

	if scanErr != nil && cfg.DebugMode() && !errors.Is(scanErr, context.Canceled) {
		debugReq, _ := json.Marshal(newBody)
		log.Printf("[DEBUG] [StreamChat] 扫描流数据报错! error: %v", scanErr)
		log.Printf("[DEBUG] [StreamChat] 完整请求体: %s", string(debugReq))
	}

	if idleTriggered.Load() {
		return NewNetworkError(ErrStreamIdleTimeout)
	}

	if errors.Is(scanErr, context.Canceled) {
		return scanErr
	}

	if scanErr != nil {
		return classifyNetworkError(scanErr)
	}

	return nil
}

// parseRetryAfterHeader 解析上游 429 响应头 Retry-After（HTTP-date 或秒数）。
// 未设置/非法时返回 0（客户端按通用 429 语义处理）。
// 入参 map 同时兼容 net/http.Header 与 fhttp.Header（底层均为 map[string][]string）。
func parseRetryAfterHeader(h map[string][]string) int {
	if h == nil {
		return 0
	}
	v := ""
	if vals, ok := h["Retry-After"]; ok && len(vals) > 0 {
		v = strings.TrimSpace(vals[0])
	}
	if v == "" {
		return 0
	}
	if sec, err := strconv.Atoi(v); err == nil && sec >= 0 {
		return sec
	}
	if t, err := http.ParseTime(v); err == nil {
		if d := int(time.Until(t).Seconds()); d > 0 {
			return d
		}
	}
	return 0
}

// isAuthVerifyFail 判定 auth 错误是否为 rT 验证时序失败（"Failed to verify action" 或
// "The caller does not have permission"）。这类失败在同一 token 静置 500ms 后重试一次
// 即可成功（rT 时序补偿机制），其余 auth 错误（token 彻底失效）由窗口引擎换点补位承接。
func isAuthVerifyFail(ve *VertexError) bool {
	if ve == nil || ve.Kind != "auth" {
		return false
	}
	return strings.Contains(ve.Message, "Failed to verify action") ||
		strings.Contains(ve.Message, "The caller does not have permission")
}

// withRTFirstTryCompensation 是全局唯一的 rT 第一发补偿机制：
// 每个真实请求的第一发必被上游 "Failed to verify action" 拒绝，必须以同一 token
// 重发第二发才成功。换新 token 同样首轮必败，故该机制无法由窗口补位承接
// （补位每发均为新 token），只能附着在"发起真实请求"的公共动作上，
// 流式/非流式两个 L1 入口共用同一实现。
// 实测重发成功率与静置时长无关，delay 仅保留为可调参数（rt_compensation_ms，
// 默认 500ms 兼容旧版节奏；<=0 时跳过静置立即重发）。
func withRTFirstTryCompensation(ctx context.Context, delay time.Duration, attempt func() error) error {
	err := attempt()
	if err == nil || !isAuthVerifyFail(NormalizeError(err)) {
		return err
	}
	if delay > 0 && sleepCtx(ctx, delay) != nil {
		return err
	}
	return attempt()
}

// isEmptyResponseError 判断 error 是否为空响应错误（NewEmptyResponseError 构造）。
func isEmptyResponseError(err error) bool {
	var ve *VertexError
	if errors.As(err, &ve) {
		return ve.Code == 502 && ve.Kind == "network" && strings.Contains(ve.Message, "empty response")
	}
	return false
}
