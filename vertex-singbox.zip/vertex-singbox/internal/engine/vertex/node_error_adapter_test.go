package vertex

import (
	"errors"
	"testing"

	"github.com/bsfdsagfadg/vertex/internal/node/exitpool"
)

// countingPool 记录节点池被调用的次数，用于断言"适配层拒绝不归因节点"。
type countingPool struct {
	reportProbe int
	slowAvoid   int
	rateLimit   int
}

func (p *countingPool) SelectForParallel(int, bool) []exitpool.Node        { return nil }
func (p *countingPool) SelectForParallelRelaxed(int, bool) []exitpool.Node { return nil }
func (p *countingPool) NodeName(string) string                             { return "n" }
func (p *countingPool) RecordTest(string, bool, float64, string)           {}
func (p *countingPool) SelectForTokenFetch(int, bool) []exitpool.Node      { return nil }
func (p *countingPool) TokenFetchRank(string) int                          { return 0 }
func (p *countingPool) RecordTokenFetch(string, exitpool.TokenFetchOutcome, int64, string) {
}
func (p *countingPool) RecordRateLimit(string, int)                   { p.rateLimit++ }
func (p *countingPool) RecordSlowAvoid(string, int)                   { p.slowAvoid++ }
func (p *countingPool) BatchUpdateNodesDisabled([]string, bool)       {}
func (p *countingPool) ReportProbe(string, exitpool.ProbeResult) bool { p.reportProbe++; return false }
func (p *countingPool) IncInFlight(string)                            {}
func (p *countingPool) DecInFlight(string)                            {}

// TestApplyNodeFailure_AdapterRejectedDoesNotTouchHealth 适配层拒绝是请求级错误，从未发起
// 真实上游请求，绝不能计入节点失败/健康度（显式护栏，防未来把校验挪进竞速闭包）。
func TestApplyNodeFailure_AdapterRejectedDoesNotTouchHealth(t *testing.T) {
	p := &countingPool{}
	applyNodeFailure(p, "vless://x@example.com:443",
		NewAdapterRejectedError("unsupported image URL", "messages[0].content[0].image_url.url", nil))
	if p.reportProbe != 0 || p.slowAvoid != 0 || p.rateLimit != 0 {
		t.Fatalf("适配层拒绝不得触碰节点健康: %+v", p)
	}

	// 对照：普通网络失败仍应上报（护栏没有误伤既有归因）。
	applyNodeFailure(p, "vless://x@example.com:443", NewNetworkError(errors.New("connection reset by peer")))
	if p.reportProbe == 0 {
		t.Fatal("普通网络失败仍应上报节点池")
	}
}

// TestClassifyBatch_AdapterRejectedFailFast 适配层拒绝 → FailFast：请求级错误，
// 不换节点、不重试，直接返回 400。
func TestClassifyBatch_AdapterRejectedFailFast(t *testing.T) {
	ve := NewAdapterRejectedError("unsupported content type", "messages[0].content[0].type", nil)
	if got := ve.ClassifyBatch(); got != FailFast {
		t.Fatalf("ClassifyBatch=%v, want FailFast", got)
	}
	if !ve.IsGlobalHardError() {
		t.Fatal("适配层拒绝应视为请求级硬错误")
	}
	if ve.Code != 400 {
		t.Fatalf("Code=%d, want 400", ve.Code)
	}
	if ve.Param == "" {
		t.Fatal("Param 应保留以供客户端定位出错字段")
	}
}
